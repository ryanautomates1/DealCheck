function pe(){const e={};try{document.querySelectorAll('script[type="application/ld+json"]').forEach(a=>{var n,r;try{const i=JSON.parse(a.textContent||"{}");if(i["@type"]==="RealEstateAgent"||i["@type"]==="Product"||i["@type"]==="Place"||i["@type"]==="Offer"){if(i.address){const s=typeof i.address=="string"?i.address:i.address.streetAddress;s&&!e.address&&(e.address={value:s,confidence:.9,source:"json-ld"})}if((n=i.offers)!=null&&n.price&&!e.listPrice){const s=typeof i.offers.price=="number"?i.offers.price:parseFloat(i.offers.price);s>1e4&&s<1e7&&(e.listPrice={value:s,confidence:.9,source:"json-ld"})}if(i.price&&!e.listPrice){const s=typeof i.price=="number"?i.price:parseFloat(i.price);s>1e4&&s<1e7&&(e.listPrice={value:s,confidence:.9,source:"json-ld"})}}if(i["@graph"]&&Array.isArray(i["@graph"])){for(const s of i["@graph"])if(s["@type"]==="Product"||s["@type"]==="Offer"){if((r=s.offers)!=null&&r.price&&!e.listPrice){const o=typeof s.offers.price=="number"?s.offers.price:parseFloat(s.offers.price);o>1e4&&o<1e7&&(e.listPrice={value:o,confidence:.9,source:"json-ld"})}if(s.price&&!e.listPrice){const o=typeof s.price=="number"?s.price:parseFloat(s.price);o>1e4&&o<1e7&&(e.listPrice={value:o,confidence:.9,source:"json-ld"})}}}}catch{}})}catch{}return e}function ue(){var t,a;const e={};try{const n=['[data-testid="tax-history"]','[data-testid="public-tax-history"]','section:has(h2:contains("tax"))','div:has(h3:contains("tax"))'],r=document.querySelectorAll("h2, h3, h4, h5, h6, span, div");let i=null;for(const s of r){const o=((t=s.textContent)==null?void 0:t.toLowerCase())||"";if(o.includes("public tax history")||o.includes("tax history")){i=s.closest("section")||s.closest('div[class*="tax"]')||s.parentElement;break}}if(!i){const s=document.querySelectorAll("table");for(const o of s){const c=((a=o.textContent)==null?void 0:a.toLowerCase())||"";if(c.includes("property tax")&&c.includes("year")){i=o.parentElement;break}}}if(i){const s=i.querySelectorAll('tr, [role="row"], div[class*="row"]');let o=0,c=0;for(const l of s){const f=l.textContent||"",y=f.match(/\b(20\d{2})\b/),v=f.match(/\$\s*([\d,]+)/);if(y&&v){const u=parseInt(y[1],10),m=parseInt(v[1].replace(/,/g,""),10);m>=100&&m<=5e5&&u>o&&(o=u,c=m)}}c>0&&o>0&&(e.taxesAnnual={value:c,confidence:.95,source:`tax-history-${o}`},e.taxYear={value:o,confidence:.95,source:"tax-history"})}if(!e.taxesAnnual){const s=document.body.innerText,o=/(?:tax|taxes)[\s\S]{0,200}?(20\d{2})\s+\$?([\d,]+)/gi;let c,l=0,f=0;for(;(c=o.exec(s))!==null;){const y=parseInt(c[1],10),v=parseInt(c[2].replace(/,/g,""),10);v>=100&&v<=5e5&&y>l&&(l=y,f=v)}f>0&&l>0&&(e.taxesAnnual={value:f,confidence:.85,source:`tax-history-${l}`},e.taxYear={value:l,confidence:.85,source:"tax-history"})}}catch{}return e}function fe(){const e={};try{const t=document.body.innerText,a=/property\s*taxes[:\s]*\$\s*([\d,]+)/gi;let n;for(;(n=a.exec(t))!==null;){const s=parseInt(n[1].replace(/,/g,""),10);if(s>=50&&s<=2e4){const o=s*12;(!e.taxesAnnual||e.taxesAnnual.confidence<.9)&&(e.taxesAnnual={value:o,confidence:.9,source:"payment-breakdown"});break}}const r=[/home(?:owners?)?\s*insurance[:\s]*\$\s*([\d,]+)/gi,/insurance[:\s]*\$\s*([\d,]+)(?:\s*\/?\s*mo)?/gi];for(const s of r){let o;for(;(o=s.exec(t))!==null;){const c=parseInt(o[1].replace(/,/g,""),10);if(c>=20&&c<=5e3){const l=c*12;if(!e.insuranceAnnual){e.insuranceAnnual={value:l,confidence:.9,source:"payment-breakdown"};break}}}if(e.insuranceAnnual)break}const i=document.querySelectorAll('[class*="payment"], [class*="breakdown"], [data-testid*="payment"]');for(const s of i){const o=s.textContent||"";if(!e.insuranceAnnual&&/home\s*insurance|insurance/i.test(o)){const c=o.match(/\$\s*([\d,]+)/);if(c){const l=parseInt(c[1].replace(/,/g,""),10);l>=20&&l<=5e3&&(e.insuranceAnnual={value:l*12,confidence:.92,source:"payment-breakdown"})}}if(!e.taxesAnnual&&/property\s*tax/i.test(o)){const c=o.match(/\$\s*([\d,]+)/);if(c){const l=parseInt(c[1].replace(/,/g,""),10);l>=50&&l<=2e4&&(e.taxesAnnual={value:l*12,confidence:.88,source:"payment-breakdown"})}}}}catch{}return e}function he(){var v;const e={},t=document.body.innerText.toLowerCase(),a=['h1[data-test="property-title"]','[data-testid="property-address"]',".ds-address-container","h1.address",'[class*="address"]','h1[class*="address"]',".property-address",'[data-test="property-address"]',"h1","h2"];for(const u of a){const m=document.querySelectorAll(u);for(const p of Array.from(m))if(!e.address){const h=(v=p.textContent)==null?void 0:v.trim();if(h&&h.length>10&&/\d/.test(h)&&(h.includes("St")||h.includes("Street")||h.includes("Ave")||h.includes("Avenue")||h.includes("Rd")||h.includes("Road")||h.includes("Dr")||h.includes("Drive")||h.includes("Ln")||h.includes("Lane")||h.includes("Blvd")||h.includes("Boulevard")||/,\s*[A-Z]{2}\s+\d{5}/.test(h))){e.address={value:h,confidence:.85,source:"semantic-dom"};break}}if(e.address)break}if(!e.address){const u=/(\d+\s+[A-Za-z\s]+(?:St|Street|Ave|Avenue|Rd|Road|Dr|Drive|Ln|Lane|Blvd|Boulevard|Ct|Court|Pl|Place|Way|Cir|Circle)[^,]*,\s*[A-Z]{2}\s+\d{5})/i,m=document.body.innerText.match(u);m&&(e.address={value:m[1].trim(),confidence:.7,source:"semantic-dom"})}const n=u=>{var P;const m=[],p=document.createTreeWalker(document.body,NodeFilter.SHOW_ELEMENT);let h=p.currentNode;for(;h;){const w=h,k=((P=w.textContent)==null?void 0:P.trim())||"";k.includes(u)&&k.length<u.length+100&&m.push(w),h=p.nextNode()}return m.length>0?m.sort((w,k)=>{var b,C;return(((b=w.textContent)==null?void 0:b.length)||0)-(((C=k.textContent)==null?void 0:C.length)||0)})[0]:null},r=u=>{const p=u.toLowerCase().split("zestimate")[0].match(/\$([1-9]\d{0,2}(?:,\d{3})+)/);if(p){const h=parseInt(p[1].replace(/,/g,""),10);if(h>=5e4&&h<=5e7)return h}return null};if(e.address&&!e.listPrice){const u=e.address.value,m=n(u);if(m){console.log("[DealMetrics] Found address element:",m.tagName,m.className);let p=m,h=0;for(;p&&h<8;){const P=p.textContent||"",w=r(P);if(w&&P.length<1e3){e.listPrice={value:w,confidence:.98,source:"semantic-dom"},console.log("[DealMetrics] Found price in address container:",w);break}p=p.parentElement,h++}}}if(!e.listPrice){const u=document.body.innerText,m=r(u);m&&(e.listPrice={value:m,confidence:.7,source:"semantic-dom"},console.log("[DealMetrics] Found price via fallback text search:",m))}const i=[/(\d+)\s*(?:bed|bedroom)/i,/bedrooms?[:\s]*(\d+)/i];for(const u of i){const m=t.match(u);if(m&&!e.beds){const p=parseInt(m[1],10);if(p>=0&&p<=20){e.beds={value:p,confidence:.7,source:"semantic-dom"};break}}}const s=[/(\d+(?:\.\d+)?)\s*(?:bath|bathroom)/i,/bathrooms?[:\s]*(\d+(?:\.\d+)?)/i];for(const u of s){const m=t.match(u);if(m&&!e.baths){const p=parseFloat(m[1]);if(p>=0&&p<=20){e.baths={value:p,confidence:.7,source:"semantic-dom"};break}}}const o=[/(\d{1,3}(?:,\d{3})*)\s*(?:sqft|sq\.?\s*ft|square\s*feet)/i,/(\d{1,3}(?:,\d{3})*)\s*(?:sq|ft²)/i];for(const u of o){const m=t.match(u);if(m&&!e.sqft){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=100&&p<=5e4){e.sqft={value:p,confidence:.7,source:"semantic-dom"};break}}}const c=[/hoa[:\s]*\$?([\d,]+)\s*(?:per\s*month|monthly|mo)/i,/monthly\s*hoa[:\s]*\$?([\d,]+)/i];for(const u of c){const m=t.match(u);if(m&&!e.hoaMonthly){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=0&&p<=1e4){e.hoaMonthly={value:p,confidence:.6,source:"semantic-dom"};break}}}const l=[/(?:annual|yearly)\s*tax[:\s]*\$?([\d,]+)/i,/taxes?[:\s]*\$?([\d,]+)\s*(?:per\s*year|annually)/i];for(const u of l){const m=t.match(u);if(m&&!e.taxesAnnual){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=0&&p<=1e5){e.taxesAnnual={value:p,confidence:.6,source:"semantic-dom"};break}}}const f=[/(single\s*family|condo|condominium|townhouse|townhome|multi-family)/i];for(const u of f){const m=t.match(u);if(m&&!e.propertyType){let p=m[1].toLowerCase();p.includes("single family")?p="Single Family":p.includes("condo")?p="Condo":p.includes("town")?p="Townhouse":p.includes("multi")&&(p="Multi-Family"),e.propertyType={value:p,confidence:.6,source:"semantic-dom"};break}}const y=[/built[:\s]*(\d{4})/i,/year\s*built[:\s]*(\d{4})/i,/(\d{4})\s*(?:built|constructed)/i];for(const u of y){const m=t.match(u);if(m&&!e.yearBuilt){const p=parseInt(m[1],10);if(p>=1800&&p<=new Date().getFullYear()+1){e.yearBuilt={value:p,confidence:.6,source:"semantic-dom"};break}}}return e}function ge(e){const t={};if(e.toLowerCase(),!t.listPrice){const a=/(?:price|list|asking)[^$]*\$([\d,]+)/gi,n=[];let r;for(;(r=a.exec(e))!==null;){const i=parseInt(r[1].replace(/,/g,""),10);i>1e4&&i<1e7&&n.push({price:i,context:r[0].substring(0,50)})}if(n.length>0){const i=n.find(s=>s.context.toLowerCase().includes("list")||s.context.toLowerCase().includes("asking"))||n[0];t.listPrice={value:i.price,confidence:.4,source:"regex"}}}return t}function ee(){const e={},t=pe();Object.assign(e,t);const a=ue();for(const[o,c]of Object.entries(a))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const n=fe();for(const[o,c]of Object.entries(n))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const r=he();for(const[o,c]of Object.entries(r))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const i=ge(document.body.innerText);for(const[o,c]of Object.entries(i))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);if(e.address){const o=ye(e.address.value);o.city&&!e.city&&(e.city={value:o.city,confidence:.7,source:"parsed"}),o.state&&!e.state&&(e.state={value:o.state,confidence:.7,source:"parsed"}),o.zip&&!e.zip&&(e.zip={value:o.zip,confidence:.7,source:"parsed"})}let s="regex_v1";return Object.keys(t).length>0?s="structured_v1":Object.keys(r).length>0&&(s="semantic_v1"),{fields:e,extractorVersion:s}}function ye(e){const t={},a=e.match(/([^,]+),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)/);if(a)t.city=a[1].trim(),t.state=a[2],t.zip=a[3];else{const n=e.match(/([A-Z]{2})\s+(\d{5}(?:-\d{4})?)/);n&&(t.state=n[1],t.zip=n[2])}return t}function te(){const e=window.location.href;return e.includes("zillow.com/homedetails/")||e.includes("zillow.com/homes/")&&e.includes("_zpid")}function xe(e){const t=document.createElement("button");return t.id="dealmetrics-floating-btn",t.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
      <polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
    <span>Analyze</span>
  `,t.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2147483646;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    color: white;
    border: none;
    border-radius: 50px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  `,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.05)",t.style.boxShadow="0 6px 20px rgba(37, 99, 235, 0.5), 0 4px 10px rgba(0, 0, 0, 0.15)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)",t.style.boxShadow="0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)"}),t.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation(),e()}),t}function ne(e,t){const a=e.querySelector("span");a&&(a.textContent=t?"Close":"Analyze"),t?(e.style.background="linear-gradient(135deg, #64748b 0%, #475569 100%)",e.style.boxShadow="0 4px 14px rgba(100, 116, 139, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)"):(e.style.background="linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)",e.style.boxShadow="0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)")}function be(e){if(document.getElementById("dealmetrics-floating-btn"))return document.getElementById("dealmetrics-floating-btn");if(!te())return null;const t=xe(e);return document.body.appendChild(t),t}function E(e,t,a){if(e===0||a===0)return 0;const n=t/100/12,r=a*12;return n===0?e/r:e*n*Math.pow(1+n,r)/(Math.pow(1+n,r)-1)}function ve(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),a=E(t,e.interestRate,e.termYears),n=e.taxesAnnual/12,r=e.insuranceAnnual/12,i=e.pmiEnabled&&e.pmiMonthly||0;return a+i+n+r+e.hoaMonthly+e.utilitiesMonthly}function j(e){const t=e.rentMonthly+e.otherIncomeMonthly,a=t*(e.vacancyRate/100),n=t-a,i=e.rentMonthly===0&&e.managementRate===0?e.purchasePrice/100:t,s=i*(e.maintenanceRate/100),o=i*(e.capexRate/100),c=t*(e.managementRate/100),l=s+o+c+e.taxesAnnual/12+e.insuranceAnnual/12+e.hoaMonthly+e.utilitiesMonthly,f=n-l,y=f*12;return{monthly:f,annual:y}}function Z(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),a=E(t,e.interestRate,e.termYears),n=e.pmiEnabled&&e.pmiMonthly||0,r=a+n;return{monthly:r,annual:r*12}}function ae(e){const t=j(e),a=Z(e),n=t.monthly-a.monthly,r=n*12;return{monthly:n,annual:r}}function we(e){const t=j(e);return e.purchasePrice===0?0:t.annual/e.purchasePrice*100}function Pe(e){const t=ae(e),a=N(e);return a===0?0:t.annual/a*100}function Re(e){const t=j(e),a=Z(e);return a.annual===0?0:t.annual/a.annual}function ke(e){const t=Z(e),a=e.taxesAnnual/12+e.insuranceAnnual/12+e.hoaMonthly+e.utilitiesMonthly,n=e.vacancyRate/100,r=e.maintenanceRate/100,i=e.capexRate/100,s=e.managementRate/100,o=1-n-r-i-s;if(o<=0)return t.monthly+a;const c=(t.monthly+a-e.otherIncomeMonthly)/o;return Math.max(0,c)}function N(e){const t=e.purchasePrice*(e.downPaymentPct/100),a=e.purchasePrice*(e.closingCostRate/100);return t+a+e.rehabCost}function Me(e){const t=ve(e),a=j(e),n=ae(e),r=we(e),i=Pe(e),s=Re(e),o=ke(e),c=N(e);return{totalMonthlyPayment:t,noiMonthly:a.monthly,noiAnnual:a.annual,cashFlowMonthly:n.monthly,cashFlowAnnual:n.annual,capRate:r,cashOnCash:i,dscr:s,breakEvenRentMonthly:o,allInCashRequired:c}}function G(e,t,a,n){if(n<=0)return e;if(n>=a)return 0;const r=t/100/12,i=a*12,s=E(e,t,a),o=n*12;if(r===0)return e-s*o;const c=e*(Math.pow(1+r,i)-Math.pow(1+r,o))/(Math.pow(1+r,i)-1);return Math.max(0,c)}function W(e,t,a,n){const r=G(e,t,a,n-1),i=G(e,t,a,n);return r-i}function Ae(e,t,a,n){const i=E(e,t,a)*12,s=W(e,t,a,n);return i-s}function Ce(e,t,a=0){const{underwritingInputs:n,appreciationRate:r,rentGrowthRate:i,expenseGrowthRate:s}=e,o=n.purchasePrice*(1-n.downPaymentPct/100),c=n.purchasePrice*Math.pow(1+r/100,t),l=G(o,n.interestRate,n.termYears,t),f=c-l,y=Math.pow(1+i/100,t-1),v=n.rentMonthly*12*y,u=n.otherIncomeMonthly*12*y,m=v+u,p=m*(n.vacancyRate/100),h=m-p,P=Math.pow(1+s/100,t-1),w=n.taxesAnnual*P,k=n.insuranceAnnual*P,b=n.hoaMonthly*12*P,C=n.utilitiesMonthly*12*P,M=m*(n.maintenanceRate/100),I=m*(n.capexRate/100),T=m*(n.managementRate/100),B=w+k+b+C+M+I+T,D=h-B,H=E(o,n.interestRate,n.termYears),_=n.pmiEnabled&&n.pmiMonthly||0,q=(H+_)*12,de=W(o,n.interestRate,n.termYears,t),le=Ae(o,n.interestRate,n.termYears,t),J=D-q,me=a+J;return{year:t,propertyValue:c,loanBalance:l,equity:f,rentAnnual:v,otherIncomeAnnual:u,grossIncomeAnnual:m,vacancyLossAnnual:p,operatingExpensesAnnual:B,noiAnnual:D,debtServiceAnnual:q,principalPaidAnnual:de,interestPaidAnnual:le,cashFlowAnnual:J,cumulativeCashFlow:me}}function $e(e){const t=[];let a=0;for(let n=1;n<=e.holdingPeriodYears;n++){const r=Ce(e,n,a);t.push(r),a=r.cumulativeCashFlow}return t}function Se(e,t=100,a=1e-4){const n=c=>e.reduce((l,f,y)=>l+f/Math.pow(1+c,y),0),r=c=>e.reduce((l,f,y)=>y===0?l:l-y*f/Math.pow(1+c,y+1),0);let i=.1;for(let c=0;c<t;c++){const l=n(i),f=r(i);if(Math.abs(f)<1e-10)break;const y=i-l/f;if(y<-.99?i=-.99:y>10?i=10:i=y,Math.abs(l)<a)return i*100}let s=-.99,o=10;for(let c=0;c<t;c++){const l=(s+o)/2,f=n(l);if(Math.abs(f)<a||(o-s)/2<a)return l*100;n(s)*f<0?o=l:s=l}return i*100}function Ie(e,t){const a=t[t.length-1],n=N(e.underwritingInputs),r=a.propertyValue,i=r*(e.sellingCostRate/100),s=a.loanBalance,o=r-i-s,c=a.cumulativeCashFlow,l=o+c-n,f=n>0?l/n*100:0,y=e.holdingPeriodYears,v=n+l,u=n>0&&y>0?(Math.pow(v/n,1/y)-1)*100:0;return{salePrice:r,sellingCosts:i,loanPayoff:s,netProceedsFromSale:o,cumulativeCashFlow:c,totalProfit:l,initialInvestment:n,totalROI:f,annualizedROI:u}}function Te(e){const t=$e(e),a=Ie(e,t),n=N(e.underwritingInputs),r=[-n];for(let c=0;c<t.length;c++){const l=t[c];c===t.length-1?r.push(l.cashFlowAnnual+a.netProceedsFromSale):r.push(l.cashFlowAnnual)}const i=Se(r),s=a.cumulativeCashFlow+a.netProceedsFromSale,o=n>0?s/n:0;return{yearlyProjections:t,exitScenario:a,irr:i,equityMultiple:o}}function Ee(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),a=E(t,e.interestRate,e.termYears),n=e.taxesAnnual/12,r=e.insuranceAnnual/12,i=e.hoaMonthly,s=e.pmiEnabled&&e.pmiMonthly||0,o=e.purchasePrice*(e.maintenanceRate/100/12)+e.purchasePrice*(e.capexRate/100/12),c=a+s+n+r+i+e.utilitiesMonthly+o,l=e.purchasePrice*(e.downPaymentPct/100),f=e.purchasePrice*(e.closingCostRate/100),y=l+f+e.rehabCost,v=c*12,u=W(t,e.interestRate,e.termYears,1),m=v-u;return{allInMonthlyCost:c,mortgagePI:a,monthlyTaxes:n,monthlyInsurance:r,monthlyHOA:i,monthlyMaintenanceReserve:o,cashRequiredAtClose:y,annualGrossCost:v,annualPrincipalPaydown:u,annualNetCostOfOwnership:m}}const Fe={purchaseType:"primary_residence",downPaymentPct:20,interestRate:7,termYears:30,closingCostRate:3,maintenanceRate:.5,capexRate:.5,vacancyRate:0,managementRate:0,estimatedRent:0,holdingPeriodYears:5,appreciationRate:3,rentGrowthRate:3,expenseGrowthRate:3,sellingCostRate:6},O={maintenanceRate:8,capexRate:5,vacancyRate:5,managementRate:8};function z(e){return e==null?"":String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}let R=null,d={...Fe},x={},A=!1,$=null;async function ze(){try{$=(await chrome.storage.sync.get(["authToken","userEmail"])).authToken||null,A=!!$}catch{A=!1,$=null}}function g(e){return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:0,maximumFractionDigits:0}).format(e)}function F(e,t=1){return`${e.toFixed(t)}%`}function se(){const e=x.listPrice||0,t=d.purchaseType==="primary_residence";return{purchasePrice:e,closingCostRate:d.closingCostRate,rehabCost:0,downPaymentPct:d.downPaymentPct,interestRate:d.interestRate,termYears:d.termYears,pmiEnabled:d.downPaymentPct<20,pmiMonthly:d.downPaymentPct<20?e*.005/12:0,taxesAnnual:x.taxesAnnual||e*.012,insuranceAnnual:x.insuranceAnnual||e*.0035,hoaMonthly:x.hoaMonthly||0,utilitiesMonthly:0,rentMonthly:t?0:d.estimatedRent||e*.007,otherIncomeMonthly:0,vacancyRate:t?0:d.vacancyRate,maintenanceRate:d.maintenanceRate,capexRate:d.capexRate,managementRate:t?0:d.managementRate}}function Le(){return{underwritingInputs:se(),holdingPeriodYears:d.holdingPeriodYears,appreciationRate:d.appreciationRate,rentGrowthRate:d.rentGrowthRate,expenseGrowthRate:d.expenseGrowthRate,sellingCostRate:d.sellingCostRate}}function oe(){const e=se(),t=Me(e),a=d.purchaseType??"primary_residence",n=String(a).toLowerCase()==="primary_residence",r=n?Ee(e):null,i=Le(),s=d.holdingPeriodYears>0?Te(i):null,o=z(x.address||"Property Address"),c=x.listPrice?g(x.listPrice):"$--",l=z(String(x.beds??"--")),f=z(String(x.baths??"--")),y=z(x.sqft?x.sqft.toLocaleString():"--"),u=!n?`
      <div class="dm-section dm-metrics dm-premium ${A?"":"dm-locked"}">
        <div class="dm-section-header">
          <span>Advanced Analysis</span>
          ${A?"":'<span class="dm-badge dm-badge-premium">PRO</span>'}
        </div>
        ${A?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">Cap Rate</span>
          <span class="dm-metric-value">${F(t.capRate)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">NOI (Annual)</span>
          <span class="dm-metric-value">${g(t.noiAnnual)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">DSCR</span>
          <span class="dm-metric-value">${t.dscr.toFixed(2)}x</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">Break-Even Rent</span>
          <span class="dm-metric-value">${g(t.breakEvenRentMonthly)}</span>
        </div>
        `:`
        <div class="dm-lock-overlay">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <span>Cap Rate, NOI, DSCR, IRR...</span>
          <button class="dm-btn dm-btn-primary dm-btn-small" id="dm-sign-in">Sign in to unlock</button>
        </div>
        `}
      </div>
      `:"",m=e.purchasePrice*(1-e.downPaymentPct/100),p=m>0?m*(e.interestRate/100/12)*Math.pow(1+e.interestRate/100/12,e.termYears*12)/(Math.pow(1+e.interestRate/100/12,e.termYears*12)-1):0,h=e.taxesAnnual/12,P=e.insuranceAnnual/12,w=e.pmiEnabled?e.pmiMonthly:0,k=p+w+h+P+e.hoaMonthly;return`
    <div class="dm-sidebar-header">
      <div class="dm-sidebar-title">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
          <polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
        <span>DealMetrics</span>
      </div>
      <button class="dm-close-btn" id="dm-close-sidebar">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    
    <div class="dm-sidebar-content">
      <!-- Property Summary -->
      <div class="dm-section dm-property-summary">
        <div class="dm-property-address">${o}</div>
        <div class="dm-property-details">
          <span class="dm-price">${c}</span>
          <span class="dm-separator">|</span>
          <span>${l} bd</span>
          <span class="dm-separator">|</span>
          <span>${f} ba</span>
          <span class="dm-separator">|</span>
          <span>${y} sqft</span>
        </div>
        <button class="dm-refresh-btn" id="dm-refresh-data">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 4v6h-6M1 20v-6h6"/>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
          </svg>
          Refresh
        </button>
      </div>
      
      <!-- Assumptions -->
      <div class="dm-section dm-assumptions">
        <div class="dm-section-header">
          <span>Assumptions</span>
          <button class="dm-toggle-advanced" id="dm-toggle-advanced">Advanced</button>
        </div>
        
        <div class="dm-input-row">
          <label>Purchase Type</label>
          <select id="dm-purchase-type" class="dm-select">
            <option value="primary_residence" ${d.purchaseType==="primary_residence"?"selected":""}>Primary Residence</option>
            <option value="investment_property" ${d.purchaseType==="investment_property"?"selected":""}>Investment</option>
            <option value="house_hack" ${d.purchaseType==="house_hack"?"selected":""}>House Hack</option>
          </select>
        </div>
        
        <div class="dm-input-row">
          <label>Down Payment</label>
          <div class="dm-input-group">
            <input type="number" id="dm-down-payment" value="${d.downPaymentPct}" min="0" max="100" step="1" class="dm-input">
            <span class="dm-input-suffix">%</span>
          </div>
        </div>
        
        <div class="dm-input-row">
          <label>Interest Rate</label>
          <div class="dm-input-group">
            <input type="number" id="dm-interest-rate" value="${d.interestRate}" min="0" max="20" step="0.125" class="dm-input">
            <span class="dm-input-suffix">%</span>
          </div>
        </div>
        
        <div class="dm-input-row">
          <label>Loan Term</label>
          <select id="dm-loan-term" class="dm-select">
            <option value="30" ${d.termYears===30?"selected":""}>30 years</option>
            <option value="15" ${d.termYears===15?"selected":""}>15 years</option>
          </select>
        </div>
        
        <!-- Advanced inputs (hidden by default) -->
        <div class="dm-advanced-inputs" id="dm-advanced-inputs" style="display: none;">
          <div class="dm-input-row">
            <label>Closing Costs</label>
            <div class="dm-input-group">
              <input type="number" id="dm-closing-costs" value="${d.closingCostRate}" min="0" max="10" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          ${n?"":`
          <div class="dm-input-row">
            <label>Vacancy Rate</label>
            <div class="dm-input-group">
              <input type="number" id="dm-vacancy" value="${d.vacancyRate}" min="0" max="50" step="1" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          <div class="dm-input-row">
            <label>Management Fee</label>
            <div class="dm-input-group">
              <input type="number" id="dm-management" value="${d.managementRate}" min="0" max="20" step="1" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          `}
          
          <div class="dm-input-row">
            <label>Maintenance</label>
            <div class="dm-input-group">
              <input type="number" id="dm-maintenance" value="${d.maintenanceRate}" min="0" max="20" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          <div class="dm-input-row">
            <label>CapEx Reserve</label>
            <div class="dm-input-group">
              <input type="number" id="dm-capex" value="${d.capexRate}" min="0" max="20" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          ${n?"":`
          <div class="dm-input-row">
            <label>Expected Rent</label>
            <div class="dm-input-group">
              <span class="dm-input-prefix">$</span>
              <input type="number" id="dm-rent" value="${d.estimatedRent}" min="0" step="50" class="dm-input dm-input-currency">
              <span class="dm-input-suffix">/mo</span>
            </div>
          </div>
          `}
        </div>
      </div>
      
      <!-- Monthly Payment Breakdown (FREE) -->
      <div class="dm-section dm-metrics">
        <div class="dm-section-header">
          <span>Monthly Payment</span>
        </div>
        
        <div class="dm-metric-row">
          <span class="dm-metric-label">Principal & Interest</span>
          <span class="dm-metric-value">${g(p)}</span>
        </div>
        ${w>0?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">PMI</span>
          <span class="dm-metric-value">${g(w)}</span>
        </div>
        `:""}
        <div class="dm-metric-row">
          <span class="dm-metric-label">
            Property Taxes
            <span class="dm-tax-source">${x.taxSource==="actual"&&x.taxYear?`(${x.taxYear})`:"(est.)"}</span>
          </span>
          <span class="dm-metric-value">${g(h)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">
            Insurance
            <span class="dm-tax-source">${x.insuranceSource==="actual"?"(Zillow)":"(est.)"}</span>
          </span>
          <span class="dm-metric-value">${g(P)}</span>
        </div>
        ${e.hoaMonthly>0?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">HOA</span>
          <span class="dm-metric-value">${g(e.hoaMonthly)}</span>
        </div>
        `:""}
        <div class="dm-metric-row dm-metric-total">
          <span class="dm-metric-label">Total Monthly</span>
          <span class="dm-metric-value">${g(k)}</span>
        </div>
      </div>
      
      ${n&&r?`
      <!-- Primary residence headline (mimic dashboard) -->
      <div class="dm-section dm-primary-headline">
        <div class="dm-section-header">
          <span>Primary Residence</span>
        </div>
        <div class="dm-primary-cards">
          <div class="dm-primary-card dm-primary-card-blue">
            <div class="dm-primary-card-label">All-In Monthly Cost</div>
            <div class="dm-primary-card-value">${g(r.allInMonthlyCost)}<span class="dm-primary-card-suffix">/mo</span></div>
          </div>
          <div class="dm-primary-card dm-primary-card-amber">
            <div class="dm-primary-card-label">Cash to Close</div>
            <div class="dm-primary-card-value">${g(r.cashRequiredAtClose)}</div>
          </div>
          <div class="dm-primary-card dm-primary-card-purple">
            <div class="dm-primary-card-label">True Monthly Cost</div>
            <div class="dm-primary-card-value">${g(r.annualNetCostOfOwnership/12)}<span class="dm-primary-card-suffix">/mo</span></div>
          </div>
        </div>
      </div>
      `:""}
      
      <!-- Key Metrics (FREE) -->
      <div class="dm-section dm-metrics">
        <div class="dm-section-header">
          <span>Key Metrics</span>
          <span class="dm-badge dm-badge-free">FREE</span>
        </div>
        
        <div class="dm-metric-row dm-metric-highlight">
          <span class="dm-metric-label">Cash Required</span>
          <span class="dm-metric-value">${g(t.allInCashRequired)}</span>
        </div>
        
        ${n?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">True Monthly Cost</span>
          <span class="dm-metric-value dm-metric-subtext">
            ${g(r!=null&&r.annualNetCostOfOwnership?r.annualNetCostOfOwnership/12:0)}
            <small>(after equity)</small>
          </span>
        </div>
        `:`
        <div class="dm-metric-row ${t.cashFlowMonthly>=0?"dm-positive":"dm-negative"}">
          <span class="dm-metric-label">Monthly Cash Flow</span>
          <span class="dm-metric-value">${g(t.cashFlowMonthly)}</span>
        </div>
        
        <div class="dm-metric-row ${t.cashOnCash>=0?"dm-positive":"dm-negative"}">
          <span class="dm-metric-label">Cash-on-Cash Return</span>
          <span class="dm-metric-value">${F(t.cashOnCash)}</span>
        </div>
        `}
      </div>
      
      <!-- Holding Period Analysis (website-style: assumptions + metrics + exit scenario) -->
      <div class="dm-section dm-holding-period">
        <div class="dm-section-header">
          <span>${d.holdingPeriodYears}-Year ${n?"Ownership":"Holding Period"} Analysis</span>
        </div>
        
        <p class="dm-holding-desc">Configure assumptions for multi-year projections.</p>
        
        <div class="dm-holding-inputs" id="dm-holding-inputs">
          <div class="dm-input-row">
            <label>Hold (years)</label>
            <div class="dm-input-group">
              <input type="number" id="dm-holding-years" value="${d.holdingPeriodYears}" min="1" max="30" step="1" class="dm-input">
              <span class="dm-input-suffix">yrs</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Appreciation</label>
            <div class="dm-input-group">
              <input type="number" id="dm-appreciation" value="${d.appreciationRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          ${n?"":`
          <div class="dm-input-row">
            <label>Rent Growth</label>
            <div class="dm-input-group">
              <input type="number" id="dm-rent-growth" value="${d.rentGrowthRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          `}
          <div class="dm-input-row">
            <label>Expense Growth</label>
            <div class="dm-input-group">
              <input type="number" id="dm-expense-growth" value="${d.expenseGrowthRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Selling Cost</label>
            <div class="dm-input-group">
              <input type="number" id="dm-selling-cost" value="${d.sellingCostRate}" min="0" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
        </div>
        
        ${s?(()=>{const b=s.exitScenario,C=e.purchasePrice*(1-e.downPaymentPct/100),M=Math.max(0,C-b.loanPayoff),I=b.salePrice-e.purchasePrice,T=M+I,B=T>0?I/T*100:50,D=T>0?M/T*100:50,H=n?"":`
        <div class="dm-holding-cards">
          <div class="dm-holding-card dm-card-irr">
            <div class="dm-holding-card-label">IRR</div>
            <div class="dm-holding-card-value ${s.irr>=0?"dm-positive":"dm-negative"}">${F(s.irr)}</div>
            <div class="dm-holding-card-hint">Annualized return</div>
          </div>
          <div class="dm-holding-card dm-card-em">
            <div class="dm-holding-card-label">Equity Multiple</div>
            <div class="dm-holding-card-value">${s.equityMultiple.toFixed(2)}x</div>
            <div class="dm-holding-card-hint">Total return / invested</div>
          </div>
          <div class="dm-holding-card dm-card-profit">
            <div class="dm-holding-card-label">Total Profit</div>
            <div class="dm-holding-card-value ${b.totalProfit>=0?"dm-positive":"dm-negative"}">${g(b.totalProfit)}</div>
            <div class="dm-holding-card-hint">Cash flow + sale - investment</div>
          </div>
          <div class="dm-holding-card dm-card-roi">
            <div class="dm-holding-card-label">Total ROI</div>
            <div class="dm-holding-card-value ${b.totalROI>=0?"dm-positive":"dm-negative"}">${F(b.totalROI)}</div>
            <div class="dm-holding-card-hint">Profit / initial investment</div>
          </div>
        </div>
          `,_=n&&r?`
        <div class="dm-ownership-summary">
          <div class="dm-ownership-summary-title">Ownership Summary</div>
          <p class="dm-ownership-summary-text">
            You&apos;ll need <span class="dm-summary-bold">${g(r.cashRequiredAtClose)}</span> in cash to close. Your all-in monthly cost is <span class="dm-summary-bold">${g(r.allInMonthlyCost)}/mo</span>. About <span class="dm-summary-bold">${g(r.annualPrincipalPaydown/12)}/mo</span> goes toward building equity, so your true cost of housing is about <span class="dm-summary-bold">${g(r.annualNetCostOfOwnership/12)}/mo</span>.${s?` If you sell at year ${d.holdingPeriodYears}, you&apos;d get approximately <span class="dm-summary-bold">${g(b.netProceedsFromSale)}</span> after paying off the mortgage and selling costs.`:""}
          </p>
        </div>
          `:"",q=n&&s?`
        <div class="dm-primary-equity-card">
          <div class="dm-primary-equity-card-label">Total Equity Built</div>
          <div class="dm-primary-equity-card-value">${g(T)}</div>
          <div class="dm-primary-equity-card-breakdown">
            Principal paydown: ${g(M)} · Appreciation: ${g(I)}
          </div>
        </div>
          `:"";return`
        ${H}
        ${q}
        <div class="dm-growth-graphic">
          <div class="dm-growth-title">Where your equity growth came from</div>
          <div class="dm-growth-bar">
            <div class="dm-growth-segment dm-growth-appreciation" style="width: ${Math.max(0,Math.min(100,B))}%" title="Appreciation: ${g(I)}"></div>
            <div class="dm-growth-segment dm-growth-principal" style="width: ${Math.max(0,Math.min(100,D))}%" title="Principal paydown: ${g(M)}"></div>
          </div>
          <div class="dm-growth-legend">
            <span class="dm-growth-legend-item"><span class="dm-growth-dot dm-growth-appreciation"></span> Appreciation ${g(I)}</span>
            <span class="dm-growth-legend-item"><span class="dm-growth-dot dm-growth-principal"></span> Principal paydown ${g(M)}</span>
          </div>
        </div>
        ${_}
        ${n?"":`
        <div class="dm-exit-scenario">
          <div class="dm-exit-title">Exit Scenario (Year ${d.holdingPeriodYears})</div>
          <p class="dm-exit-desc">Sale proceeds minus selling costs and remaining loan.</p>
          <div class="dm-exit-rows">
            <div class="dm-exit-row">
              <span class="dm-exit-label">Sale price</span>
              <span class="dm-exit-value">${g(b.salePrice)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">− Selling costs</span>
              <span class="dm-exit-value dm-negative">−${g(b.sellingCosts)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">− Loan balance</span>
              <span class="dm-exit-value dm-negative">−${g(b.loanPayoff)}</span>
            </div>
            <div class="dm-exit-row dm-exit-row-highlight">
              <span class="dm-exit-label">Cash to you</span>
              <span class="dm-exit-value dm-positive">${g(b.netProceedsFromSale)}</span>
            </div>
          </div>
          <div class="dm-exit-summary">
            <div class="dm-exit-summary-row">
              <span class="dm-exit-label">You put in</span>
              <span class="dm-exit-value">${g(b.initialInvestment)}</span>
            </div>
            <div class="dm-exit-summary-row">
              <span class="dm-exit-label">You get back (sale + cash flow)</span>
              <span class="dm-exit-value dm-positive">${g(b.netProceedsFromSale+b.cumulativeCashFlow)}</span>
            </div>
            <div class="dm-exit-summary-row dm-exit-profit">
              <span class="dm-exit-label">Total profit</span>
              <span class="dm-exit-value ${b.totalProfit>=0?"dm-positive":"dm-negative"}">${g(b.totalProfit)} (${F(b.totalROI)} ROI)</span>
            </div>
          </div>
        </div>
        `}
        
        `})():""}
      </div>
      
      ${u}
    </div>
    
    <!-- Footer Actions -->
    <div class="dm-sidebar-footer">
      ${A?`
      <button class="dm-btn dm-btn-primary dm-btn-full" id="dm-save-deal">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
          <polyline points="17 21 17 13 7 13 7 21"/>
          <polyline points="7 3 7 8 15 8"/>
        </svg>
        Save to Dashboard
      </button>
      `:`
      <button class="dm-btn dm-btn-primary dm-btn-full" id="dm-sign-in-footer">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
          <polyline points="10 17 15 12 10 7"/>
          <line x1="15" y1="12" x2="3" y2="12"/>
        </svg>
        Sign in to Save
      </button>
      `}
      <div class="dm-footer-links">
        <a href="https://getdealmetrics.com" target="_blank">Open DealMetrics</a>
        <a href="https://getdealmetrics.com/privacy" target="_blank">Privacy</a>
        ${A?'<button type="button" class="dm-footer-signout" id="dm-sign-out-sidebar">Sign out</button>':""}
      </div>
    </div>
  `}function Be(){return`
    #dealmetrics-sidebar {
      position: fixed;
      top: 0;
      right: 0;
      width: 360px;
      height: 100vh;
      background: #ffffff;
      box-shadow: -4px 0 20px rgba(0, 0, 0, 0.15);
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      color: #1f2937;
      font-size: 14px;
      line-height: 1.5;
    }
    
    .dm-sidebar-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 20px;
      background: linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 100%);
      color: white;
    }
    
    .dm-sidebar-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      font-size: 16px;
    }
    
    .dm-close-btn {
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 8px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s;
    }
    
    .dm-close-btn:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    .dm-sidebar-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    
    .dm-section {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 12px;
    }
    
    .dm-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      font-weight: 600;
      color: #374151;
    }
    
    .dm-primary-headline {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
    }
    
    .dm-primary-cards {
      display: grid;
      grid-template-columns: 1fr;
      gap: 8px;
    }
    
    .dm-primary-card {
      border-radius: 8px;
      padding: 10px 12px;
      border: 1px solid transparent;
    }
    
    .dm-primary-card-label {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.02em;
      margin-bottom: 2px;
    }
    
    .dm-primary-card-value {
      font-size: 15px;
      font-weight: 700;
    }
    
    .dm-primary-card-suffix {
      font-size: 12px;
      font-weight: 500;
    }
    
    .dm-primary-card-blue {
      background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
      border-color: #93c5fd;
      color: #1e40af;
    }
    
    .dm-primary-card-blue .dm-primary-card-label { color: #1d4ed8; }
    .dm-primary-card-blue .dm-primary-card-value { color: #1e3a8a; }
    
    .dm-primary-card-amber {
      background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
      border-color: #fcd34d;
      color: #92400e;
    }
    
    .dm-primary-card-amber .dm-primary-card-label { color: #b45309; }
    .dm-primary-card-amber .dm-primary-card-value { color: #78350f; }
    
    .dm-primary-card-purple {
      background: linear-gradient(135deg, #ede9fe 0%, #ddd6fe 100%);
      border-color: #c4b5fd;
      color: #5b21b6;
    }
    
    .dm-primary-card-purple .dm-primary-card-label { color: #6d28d9; }
    .dm-primary-card-purple .dm-primary-card-value { color: #4c1d95; }
    
    .dm-property-summary {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-color: #bae6fd;
    }
    
    .dm-property-address {
      font-weight: 600;
      font-size: 15px;
      color: #0f172a;
      margin-bottom: 4px;
    }
    
    .dm-property-details {
      color: #64748b;
      font-size: 13px;
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    
    .dm-price {
      font-weight: 600;
      color: #0369a1;
    }
    
    .dm-separator {
      color: #cbd5e1;
    }
    
    .dm-refresh-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      margin-top: 12px;
      padding: 6px 12px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      font-size: 12px;
      color: #64748b;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .dm-refresh-btn:hover {
      background: #f1f5f9;
      color: #334155;
    }
    
    .dm-input-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .dm-input-row label {
      font-size: 13px;
      color: #4b5563;
    }
    
    .dm-input-group {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .dm-input, .dm-select {
      width: 80px;
      padding: 6px 8px;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 13px;
      color: #1f2937;
      background: white;
      text-align: right;
    }
    
    .dm-input:focus, .dm-select:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    .dm-select {
      width: auto;
      text-align: left;
      cursor: pointer;
    }
    
    .dm-input-suffix, .dm-input-prefix {
      font-size: 12px;
      color: #9ca3af;
    }
    
    .dm-input-currency {
      width: 90px;
    }
    
    .dm-toggle-advanced {
      font-size: 12px;
      color: #6b7280;
      background: none;
      border: none;
      cursor: pointer;
      text-decoration: underline;
    }
    
    .dm-toggle-advanced:hover {
      color: #3b82f6;
    }
    
    .dm-holding-desc {
      font-size: 12px;
      color: #6b7280;
      margin: 0 0 12px 0;
    }
    
    .dm-holding-inputs {
      margin-bottom: 14px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px 12px;
    }
    
    .dm-holding-inputs .dm-input-row {
      margin-bottom: 0;
    }
    
    .dm-holding-cards {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    
    .dm-holding-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
    }
    
    .dm-holding-card-label {
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.02em;
      margin-bottom: 2px;
    }
    
    .dm-holding-card-value {
      font-size: 16px;
      font-weight: 700;
      color: #1e293b;
    }
    
    .dm-holding-card-hint {
      font-size: 10px;
      color: #94a3b8;
      margin-top: 2px;
    }
    
    .dm-ownership-summary {
      background: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
      border: 1px solid #c7d2fe;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
    }
    
    .dm-ownership-summary-title {
      font-size: 12px;
      font-weight: 600;
      color: #3730a3;
      margin-bottom: 6px;
    }
    
    .dm-ownership-summary-text {
      font-size: 12px;
      color: #4338ca;
      line-height: 1.5;
      margin: 0;
    }
    
    .dm-summary-bold {
      font-weight: 600;
      color: #1e1b4b;
    }
    
    .dm-primary-equity-card {
      background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
      border: 1px solid #93c5fd;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 12px;
    }
    
    .dm-primary-equity-card-label {
      font-size: 11px;
      font-weight: 600;
      color: #1d4ed8;
      text-transform: uppercase;
      letter-spacing: 0.02em;
      margin-bottom: 2px;
    }
    
    .dm-primary-equity-card-value {
      font-size: 16px;
      font-weight: 700;
      color: #1e3a8a;
    }
    
    .dm-primary-equity-card-breakdown {
      font-size: 10px;
      color: #1e40af;
      margin-top: 4px;
    }
    
    .dm-growth-graphic {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
    }
    
    .dm-growth-title {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 8px;
    }
    
    .dm-growth-bar {
      display: flex;
      height: 20px;
      border-radius: 6px;
      overflow: hidden;
      background: #e2e8f0;
      margin-bottom: 8px;
    }
    
    .dm-growth-segment {
      min-width: 2px;
      transition: width 0.2s ease;
    }
    
    .dm-growth-appreciation {
      background: linear-gradient(90deg, #0ea5e9, #06b6d4);
    }
    
    .dm-growth-principal {
      background: linear-gradient(90deg, #8b5cf6, #a78bfa);
    }
    
    .dm-growth-legend {
      display: flex;
      flex-wrap: wrap;
      gap: 12px 16px;
      font-size: 11px;
      color: #64748b;
    }
    
    .dm-growth-legend-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    
    .dm-growth-dot {
      width: 10px;
      height: 10px;
      border-radius: 3px;
    }
    
    .dm-growth-dot.dm-growth-appreciation {
      background: #0ea5e9;
    }
    
    .dm-growth-dot.dm-growth-principal {
      background: #8b5cf6;
    }
    
    .dm-exit-scenario {
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 12px;
    }
    
    .dm-exit-title {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 4px;
    }
    
    .dm-exit-desc {
      font-size: 11px;
      color: #64748b;
      margin-bottom: 8px;
      line-height: 1.4;
    }
    
    .dm-exit-summary {
      margin-top: 12px;
      padding-top: 10px;
      border-top: 1px solid #cbd5e1;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .dm-exit-summary-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
    }
    
    .dm-exit-summary-row.dm-exit-profit {
      font-weight: 600;
      margin-top: 4px;
    }
    
    .dm-exit-rows {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .dm-exit-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
    }
    
    .dm-exit-row-highlight {
      border-top: 1px solid #cbd5e1;
      margin-top: 4px;
      padding-top: 6px;
      font-weight: 600;
    }
    
    .dm-exit-label {
      color: #64748b;
    }
    
    .dm-exit-value {
      font-weight: 600;
      color: #1e293b;
    }
    
    .dm-yearly-summary {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
    }
    
    .dm-yearly-title {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 6px;
    }
    
    .dm-yearly-rows {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    
    .dm-yearly-row {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
    }
    
    .dm-yearly-label {
      color: #64748b;
    }
    
    .dm-yearly-value {
      font-weight: 500;
      color: #1e293b;
    }
    
    .dm-advanced-inputs {
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px dashed #e5e7eb;
    }
    
    .dm-metric-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid #f1f5f9;
    }
    
    .dm-metric-row:last-child {
      border-bottom: none;
    }
    
    .dm-metric-label {
      font-size: 13px;
      color: #6b7280;
    }
    
    .dm-tax-source {
      font-size: 10px;
      color: #9ca3af;
      font-weight: 400;
      margin-left: 4px;
    }
    
    .dm-metric-value {
      font-weight: 600;
      color: #1f2937;
    }
    
    .dm-metric-subtext {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    
    .dm-metric-subtext small {
      font-size: 10px;
      font-weight: 400;
      color: #9ca3af;
    }
    
    .dm-metric-total {
      margin-top: 8px;
      padding-top: 12px;
      border-top: 2px solid #e2e8f0;
    }
    
    .dm-metric-total .dm-metric-value {
      font-size: 16px;
      color: #0369a1;
    }
    
    .dm-metric-highlight {
      background: #f0f9ff;
      margin: -8px -16px;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 8px;
    }
    
    .dm-positive .dm-metric-value {
      color: #059669;
    }
    
    .dm-negative .dm-metric-value {
      color: #dc2626;
    }
    
    .dm-badge {
      font-size: 10px;
      font-weight: 600;
      padding: 2px 8px;
      border-radius: 10px;
      text-transform: uppercase;
    }
    
    .dm-badge-free {
      background: #dcfce7;
      color: #166534;
    }
    
    .dm-badge-premium {
      background: #fef3c7;
      color: #92400e;
    }
    
    .dm-premium.dm-locked {
      position: relative;
    }
    
    .dm-lock-overlay {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      text-align: center;
      color: #6b7280;
      gap: 8px;
    }
    
    .dm-lock-overlay svg {
      color: #9ca3af;
    }
    
    .dm-lock-overlay span {
      font-size: 12px;
    }
    
    .dm-sidebar-footer {
      padding: 16px;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
    }
    
    .dm-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 10px 16px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }
    
    .dm-btn-primary {
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
    }
    
    .dm-btn-primary:hover {
      background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
    }
    
    .dm-btn-full {
      width: 100%;
    }
    
    .dm-btn-small {
      padding: 6px 12px;
      font-size: 12px;
    }
    
    .dm-footer-links {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
      margin-top: 12px;
    }
    
    .dm-footer-links a {
      font-size: 12px;
      color: #6b7280;
      text-decoration: none;
    }
    
    .dm-footer-links a:hover {
      color: #3b82f6;
      text-decoration: underline;
    }
    
    .dm-footer-signout {
      background: none;
      border: none;
      font-size: 12px;
      color: #6b7280;
      cursor: pointer;
      padding: 0;
      font-family: inherit;
    }
    
    .dm-footer-signout:hover {
      color: #3b82f6;
      text-decoration: underline;
    }
    
    .dm-saving {
      opacity: 0.7;
      pointer-events: none;
    }
    
    .dm-success-msg {
      background: #dcfce7;
      color: #166534;
      padding: 12px;
      border-radius: 8px;
      text-align: center;
      font-size: 13px;
      margin-bottom: 12px;
    }
    
    .dm-error-msg {
      background: #fee2e2;
      color: #dc2626;
      padding: 12px;
      border-radius: 8px;
      text-align: center;
      font-size: 13px;
      margin-bottom: 12px;
    }
  `}function L(){R&&(R.innerHTML=oe(),ie())}function De(e,t){switch(e){case"dm-purchase-type":const a=t;d.purchaseType=a,a==="primary_residence"?(d.maintenanceRate=.5,d.capexRate=.5,d.vacancyRate=0,d.managementRate=0):(d.maintenanceRate=O.maintenanceRate,d.capexRate=O.capexRate,d.vacancyRate=O.vacancyRate,d.managementRate=O.managementRate);break;case"dm-down-payment":d.downPaymentPct=Number(t);break;case"dm-interest-rate":d.interestRate=Number(t);break;case"dm-loan-term":d.termYears=Number(t);break;case"dm-closing-costs":d.closingCostRate=Number(t);break;case"dm-vacancy":d.vacancyRate=Number(t);break;case"dm-management":d.managementRate=Number(t);break;case"dm-maintenance":d.maintenanceRate=Number(t);break;case"dm-capex":d.capexRate=Number(t);break;case"dm-rent":d.estimatedRent=Number(t);break;case"dm-holding-years":d.holdingPeriodYears=Math.max(1,Math.min(30,Number(t)||5));break;case"dm-appreciation":d.appreciationRate=Number(t);break;case"dm-rent-growth":d.rentGrowthRate=Number(t);break;case"dm-expense-growth":d.expenseGrowthRate=Number(t);break;case"dm-selling-cost":d.sellingCostRate=Math.max(0,Number(t));break}L()}function qe(e){try{if(!e||typeof e!="object")return null;const t=e,a=t==null?void 0:t.dealId;if(typeof a=="string")return a;const n=t==null?void 0:t.data;if(n&&typeof n=="object"){const r=n,i=r==null?void 0:r.dealId;if(typeof i=="string")return i;const s=r==null?void 0:r.deal;if(s!=null&&typeof s=="object"){const o=s==null?void 0:s.id;if(typeof o=="string")return o}}}catch{return null}return null}async function Oe(){var t;if(!$){alert("Please sign in to save deals");return}const e=document.getElementById("dm-save-deal");e&&(e.classList.add("dm-saving"),e.innerHTML="Saving...");try{const a={zillowUrl:x.zillowUrl||window.location.href,extractedData:{address:x.address,city:x.city,state:x.state,zip:x.zip,propertyType:x.propertyType,beds:x.beds,baths:x.baths,sqft:x.sqft,yearBuilt:x.yearBuilt,listPrice:x.listPrice,hoaMonthly:x.hoaMonthly,taxesAnnual:x.taxesAnnual},purchaseType:d.purchaseType,downPaymentPct:d.downPaymentPct,importedFields:Object.keys(x).filter(i=>x[i]!==void 0),missingFields:[],fieldConfidences:{},extractorVersion:"sidebar_v1"};console.log("[DealMetrics] Saving deal...",{payload:a,hasToken:!!$});const n=await chrome.runtime.sendMessage({action:"saveDeal",payload:a,authToken:$});if(console.log("[DealMetrics] Save response:",n),!n)throw new Error("No response from background script - extension may need reload");if(!n.success)throw new Error(n.error||"Failed to save deal");let r=null;try{r=qe(n)}catch{r=null}r||console.warn("[DealMetrics] Save succeeded but dealId missing from response shape:",n);try{const i=document.querySelector(".dm-sidebar-content");if(i){const s=document.createElement("div");s.className="dm-success-msg";const o=r?`Deal saved! <a href="https://getdealmetrics.com/deals/${z(r)}" target="_blank">View in Dashboard</a>`:'Deal saved! <a href="https://getdealmetrics.com/dashboard" target="_blank">View in Dashboard</a>';s.innerHTML=o,i.insertBefore(s,i.firstChild)}}catch(i){console.error("[DealMetrics] Error showing success message:",i)}e&&(e.innerHTML="Saved!",setTimeout(()=>{e&&(e.classList.remove("dm-saving"),e.innerHTML=`
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17 21 17 13 7 13 7 21"/>
              <polyline points="7 3 7 8 15 8"/>
            </svg>
            Save to Dashboard
          `)},2e3))}catch(a){console.error("Save error:",a);const n=a.message||"Failed to save deal",r=n.toLowerCase().includes("token")||n.toLowerCase().includes("unauthorized")||n.toLowerCase().includes("401");r&&(await chrome.storage.sync.remove(["authToken","refreshToken","userEmail"]),A=!1,$=null);const i=document.querySelector(".dm-sidebar-content");if(i){const s=document.createElement("div");s.className="dm-error-msg",r?s.innerHTML=`
          Session expired. <button id="dm-reauth-btn" style="color: #2563eb; text-decoration: underline; background: none; border: none; cursor: pointer;">Sign in again</button>
        `:s.textContent=n,i.insertBefore(s,i.firstChild),r&&((t=document.getElementById("dm-reauth-btn"))==null||t.addEventListener("click",()=>{V()}))}e&&(e.classList.remove("dm-saving"),e.innerHTML=`
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
          <polyline points="17 21 17 13 7 13 7 21"/>
          <polyline points="7 3 7 8 15 8"/>
        </svg>
        Save to Dashboard
      `),r&&setTimeout(()=>L(),500)}}function V(){const t=`https://getdealmetrics.com/auth/extension?_=${Date.now()}`;window.open(t,"_blank")}async function Ye(){try{await chrome.storage.sync.remove(["authToken","refreshToken","userEmail"]),A=!1,$=null,L()}catch(e){console.error("[DealMetrics] Sign out error:",e),A=!1,$=null,L()}}function ie(){var t,a,n,r,i,s;(t=document.getElementById("dm-close-sidebar"))==null||t.addEventListener("click",()=>{K()}),(a=document.getElementById("dm-refresh-data"))==null||a.addEventListener("click",()=>{re()}),(n=document.getElementById("dm-toggle-advanced"))==null||n.addEventListener("click",()=>{const o=document.getElementById("dm-advanced-inputs");o&&(o.style.display=o.style.display==="none"?"block":"none")}),["dm-purchase-type","dm-down-payment","dm-interest-rate","dm-loan-term","dm-closing-costs","dm-vacancy","dm-management","dm-maintenance","dm-capex","dm-rent","dm-holding-years","dm-appreciation","dm-rent-growth","dm-expense-growth","dm-selling-cost"].forEach(o=>{const c=document.getElementById(o);c&&c.addEventListener("change",()=>{De(o,c.value)})}),(r=document.getElementById("dm-save-deal"))==null||r.addEventListener("click",Oe),(i=document.getElementById("dm-sign-in"))==null||i.addEventListener("click",V),(s=document.getElementById("dm-sign-in-footer"))==null||s.addEventListener("click",V)}function re(){var o,c,l,f,y,v,u,m,p,h,P,w,k,b,C,M;const t=ee().fields,a=(o=t.taxesAnnual)==null?void 0:o.source,n=(a==null?void 0:a.startsWith("tax-history"))||a==="payment-breakdown",r=(c=t.taxYear)==null?void 0:c.value,s=((l=t.insuranceAnnual)==null?void 0:l.source)==="payment-breakdown";x={address:(f=t.address)==null?void 0:f.value,city:(y=t.city)==null?void 0:y.value,state:(v=t.state)==null?void 0:v.value,zip:(u=t.zip)==null?void 0:u.value,listPrice:(m=t.listPrice)==null?void 0:m.value,beds:(p=t.beds)==null?void 0:p.value,baths:(h=t.baths)==null?void 0:h.value,sqft:(P=t.sqft)==null?void 0:P.value,propertyType:(w=t.propertyType)==null?void 0:w.value,yearBuilt:(k=t.yearBuilt)==null?void 0:k.value,hoaMonthly:(b=t.hoaMonthly)==null?void 0:b.value,taxesAnnual:(C=t.taxesAnnual)==null?void 0:C.value,taxYear:r,taxSource:n?"actual":"estimated",insuranceAnnual:(M=t.insuranceAnnual)==null?void 0:M.value,insuranceSource:s?"actual":"estimated",zillowUrl:window.location.href},L()}function K(){R&&(R.remove(),R=null)}function Y(){return R!==null}async function je(){if(R)return;await ze(),re();const e="dealmetrics-sidebar-styles";if(!document.getElementById(e)){const t=document.createElement("style");t.id=e,t.textContent=Be(),document.head.appendChild(t)}R=document.createElement("div"),R.id="dealmetrics-sidebar",R.innerHTML=oe(),document.body.appendChild(R),R.addEventListener("click",t=>{const a=t.target;(a.id==="dm-sign-out-sidebar"||a.closest("#dm-sign-out-sidebar"))&&(t.preventDefault(),t.stopPropagation(),Ye())}),ie()}function ce(){Y()?K():je()}let S=null;function U(){te()&&(S=be(()=>{ce(),S&&ne(S,Y())}))}let Q=window.location.href;function X(){new MutationObserver(()=>{window.location.href!==Q&&(Q=window.location.href,K(),S&&(S.remove(),S=null),setTimeout(U,1e3))}).observe(document.body,{childList:!0,subtree:!0})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{U(),X()}):(U(),X());chrome.runtime.onMessage.addListener((e,t,a)=>{if(e.action==="extract"){try{if(!window.location.hostname.includes("zillow.com"))return a({success:!1,error:"Not on a Zillow page"}),!0;const n=ee(),r={},i=[],s={};for(const[l,f]of Object.entries(n.fields))f.value!==void 0&&f.value!==null&&(r[l]=f.value,i.push(l),s[l]=f.confidence);const o=[],c=["address","listPrice","beds","baths","sqft"];for(const l of c)i.includes(l)||o.push(l);a({success:!0,payload:{zillowUrl:window.location.href,extractedData:r,importedFields:i,missingFields:o,fieldConfidences:s,extractorVersion:n.extractorVersion}})}catch(n){a({success:!1,error:n.message||"Extraction failed"})}return!0}if(e.action==="toggleSidebar")return ce(),S&&ne(S,Y()),a({success:!0,isOpen:Y()}),!0});
