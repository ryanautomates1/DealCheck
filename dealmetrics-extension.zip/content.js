function pe(){const e={};try{document.querySelectorAll('script[type="application/ld+json"]').forEach(s=>{var n,r;try{const a=JSON.parse(s.textContent||"{}");if(a["@type"]==="RealEstateAgent"||a["@type"]==="Product"||a["@type"]==="Place"||a["@type"]==="Offer"){if(a.address){const i=typeof a.address=="string"?a.address:a.address.streetAddress;i&&!e.address&&(e.address={value:i,confidence:.9,source:"json-ld"})}if((n=a.offers)!=null&&n.price&&!e.listPrice){const i=typeof a.offers.price=="number"?a.offers.price:parseFloat(a.offers.price);i>1e4&&i<1e7&&(e.listPrice={value:i,confidence:.9,source:"json-ld"})}if(a.price&&!e.listPrice){const i=typeof a.price=="number"?a.price:parseFloat(a.price);i>1e4&&i<1e7&&(e.listPrice={value:i,confidence:.9,source:"json-ld"})}}if(a["@graph"]&&Array.isArray(a["@graph"])){for(const i of a["@graph"])if(i["@type"]==="Product"||i["@type"]==="Offer"){if((r=i.offers)!=null&&r.price&&!e.listPrice){const o=typeof i.offers.price=="number"?i.offers.price:parseFloat(i.offers.price);o>1e4&&o<1e7&&(e.listPrice={value:o,confidence:.9,source:"json-ld"})}if(i.price&&!e.listPrice){const o=typeof i.price=="number"?i.price:parseFloat(i.price);o>1e4&&o<1e7&&(e.listPrice={value:o,confidence:.9,source:"json-ld"})}}}}catch{}})}catch{}return e}function ue(){var t,s;const e={};try{const n=['[data-testid="tax-history"]','[data-testid="public-tax-history"]','section:has(h2:contains("tax"))','div:has(h3:contains("tax"))'],r=document.querySelectorAll("h2, h3, h4, h5, h6, span, div");let a=null;for(const i of r){const o=((t=i.textContent)==null?void 0:t.toLowerCase())||"";if(o.includes("public tax history")||o.includes("tax history")){a=i.closest("section")||i.closest('div[class*="tax"]')||i.parentElement;break}}if(!a){const i=document.querySelectorAll("table");for(const o of i){const c=((s=o.textContent)==null?void 0:s.toLowerCase())||"";if(c.includes("property tax")&&c.includes("year")){a=o.parentElement;break}}}if(a){const i=a.querySelectorAll('tr, [role="row"], div[class*="row"]');let o=0,c=0;for(const d of i){const f=d.textContent||"",y=f.match(/\b(20\d{2})\b/),v=f.match(/\$\s*([\d,]+)/);if(y&&v){const u=parseInt(y[1],10),m=parseInt(v[1].replace(/,/g,""),10);m>=100&&m<=5e5&&u>o&&(o=u,c=m)}}c>0&&o>0&&(e.taxesAnnual={value:c,confidence:.95,source:`tax-history-${o}`},e.taxYear={value:o,confidence:.95,source:"tax-history"})}if(!e.taxesAnnual){const i=document.body.innerText,o=/(?:tax|taxes)[\s\S]{0,200}?(20\d{2})\s+\$?([\d,]+)/gi;let c,d=0,f=0;for(;(c=o.exec(i))!==null;){const y=parseInt(c[1],10),v=parseInt(c[2].replace(/,/g,""),10);v>=100&&v<=5e5&&y>d&&(d=y,f=v)}f>0&&d>0&&(e.taxesAnnual={value:f,confidence:.85,source:`tax-history-${d}`},e.taxYear={value:d,confidence:.85,source:"tax-history"})}}catch{}return e}function fe(){const e={};try{const t=document.body.innerText,s=/property\s*taxes[:\s]*\$\s*([\d,]+)/gi;let n;for(;(n=s.exec(t))!==null;){const i=parseInt(n[1].replace(/,/g,""),10);if(i>=50&&i<=2e4){const o=i*12;(!e.taxesAnnual||e.taxesAnnual.confidence<.9)&&(e.taxesAnnual={value:o,confidence:.9,source:"payment-breakdown"});break}}const r=[/home(?:owners?)?\s*insurance[:\s]*\$\s*([\d,]+)/gi,/insurance[:\s]*\$\s*([\d,]+)(?:\s*\/?\s*mo)?/gi];for(const i of r){let o;for(;(o=i.exec(t))!==null;){const c=parseInt(o[1].replace(/,/g,""),10);if(c>=20&&c<=5e3){const d=c*12;if(!e.insuranceAnnual){e.insuranceAnnual={value:d,confidence:.9,source:"payment-breakdown"};break}}}if(e.insuranceAnnual)break}const a=document.querySelectorAll('[class*="payment"], [class*="breakdown"], [data-testid*="payment"]');for(const i of a){const o=i.textContent||"";if(!e.insuranceAnnual&&/home\s*insurance|insurance/i.test(o)){const c=o.match(/\$\s*([\d,]+)/);if(c){const d=parseInt(c[1].replace(/,/g,""),10);d>=20&&d<=5e3&&(e.insuranceAnnual={value:d*12,confidence:.92,source:"payment-breakdown"})}}if(!e.taxesAnnual&&/property\s*tax/i.test(o)){const c=o.match(/\$\s*([\d,]+)/);if(c){const d=parseInt(c[1].replace(/,/g,""),10);d>=50&&d<=2e4&&(e.taxesAnnual={value:d*12,confidence:.88,source:"payment-breakdown"})}}}}catch{}return e}function he(){var v;const e={},t=document.body.innerText.toLowerCase(),s=['h1[data-test="property-title"]','[data-testid="property-address"]',".ds-address-container","h1.address",'[class*="address"]','h1[class*="address"]',".property-address",'[data-test="property-address"]',"h1","h2"];for(const u of s){const m=document.querySelectorAll(u);for(const p of Array.from(m))if(!e.address){const h=(v=p.textContent)==null?void 0:v.trim();if(h&&h.length>10&&/\d/.test(h)&&(h.includes("St")||h.includes("Street")||h.includes("Ave")||h.includes("Avenue")||h.includes("Rd")||h.includes("Road")||h.includes("Dr")||h.includes("Drive")||h.includes("Ln")||h.includes("Lane")||h.includes("Blvd")||h.includes("Boulevard")||/,\s*[A-Z]{2}\s+\d{5}/.test(h))){e.address={value:h,confidence:.85,source:"semantic-dom"};break}}if(e.address)break}if(!e.address){const u=/(\d+\s+[A-Za-z\s]+(?:St|Street|Ave|Avenue|Rd|Road|Dr|Drive|Ln|Lane|Blvd|Boulevard|Ct|Court|Pl|Place|Way|Cir|Circle)[^,]*,\s*[A-Z]{2}\s+\d{5})/i,m=document.body.innerText.match(u);m&&(e.address={value:m[1].trim(),confidence:.7,source:"semantic-dom"})}const n=u=>{var b;const m=[],p=document.createTreeWalker(document.body,NodeFilter.SHOW_ELEMENT);let h=p.currentNode;for(;h;){const w=h,R=((b=w.textContent)==null?void 0:b.trim())||"";R.includes(u)&&R.length<u.length+100&&m.push(w),h=p.nextNode()}return m.length>0?m.sort((w,R)=>{var k,A;return(((k=w.textContent)==null?void 0:k.length)||0)-(((A=R.textContent)==null?void 0:A.length)||0)})[0]:null},r=u=>{const p=u.toLowerCase().split("zestimate")[0].match(/\$([1-9]\d{0,2}(?:,\d{3})+)/);if(p){const h=parseInt(p[1].replace(/,/g,""),10);if(h>=5e4&&h<=5e7)return h}return null};if(e.address&&!e.listPrice){const u=e.address.value,m=n(u);if(m){console.log("[DealMetrics] Found address element:",m.tagName,m.className);let p=m,h=0;for(;p&&h<8;){const b=p.textContent||"",w=r(b);if(w&&b.length<1e3){e.listPrice={value:w,confidence:.98,source:"semantic-dom"},console.log("[DealMetrics] Found price in address container:",w);break}p=p.parentElement,h++}}}if(!e.listPrice){const u=document.body.innerText,m=r(u);m&&(e.listPrice={value:m,confidence:.7,source:"semantic-dom"},console.log("[DealMetrics] Found price via fallback text search:",m))}const a=[/(\d+)\s*(?:bed|bedroom)/i,/bedrooms?[:\s]*(\d+)/i];for(const u of a){const m=t.match(u);if(m&&!e.beds){const p=parseInt(m[1],10);if(p>=0&&p<=20){e.beds={value:p,confidence:.7,source:"semantic-dom"};break}}}const i=[/(\d+(?:\.\d+)?)\s*(?:bath|bathroom)/i,/bathrooms?[:\s]*(\d+(?:\.\d+)?)/i];for(const u of i){const m=t.match(u);if(m&&!e.baths){const p=parseFloat(m[1]);if(p>=0&&p<=20){e.baths={value:p,confidence:.7,source:"semantic-dom"};break}}}const o=[/(\d{1,3}(?:,\d{3})*)\s*(?:sqft|sq\.?\s*ft|square\s*feet)/i,/(\d{1,3}(?:,\d{3})*)\s*(?:sq|ft²)/i];for(const u of o){const m=t.match(u);if(m&&!e.sqft){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=100&&p<=5e4){e.sqft={value:p,confidence:.7,source:"semantic-dom"};break}}}const c=[/hoa[:\s]*\$?([\d,]+)\s*(?:per\s*month|monthly|mo)/i,/monthly\s*hoa[:\s]*\$?([\d,]+)/i];for(const u of c){const m=t.match(u);if(m&&!e.hoaMonthly){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=0&&p<=1e4){e.hoaMonthly={value:p,confidence:.6,source:"semantic-dom"};break}}}const d=[/(?:annual|yearly)\s*tax[:\s]*\$?([\d,]+)/i,/taxes?[:\s]*\$?([\d,]+)\s*(?:per\s*year|annually)/i];for(const u of d){const m=t.match(u);if(m&&!e.taxesAnnual){const p=parseInt(m[1].replace(/,/g,""),10);if(p>=0&&p<=1e5){e.taxesAnnual={value:p,confidence:.6,source:"semantic-dom"};break}}}const f=[/(single\s*family|condo|condominium|townhouse|townhome|multi-family)/i];for(const u of f){const m=t.match(u);if(m&&!e.propertyType){let p=m[1].toLowerCase();p.includes("single family")?p="Single Family":p.includes("condo")?p="Condo":p.includes("town")?p="Townhouse":p.includes("multi")&&(p="Multi-Family"),e.propertyType={value:p,confidence:.6,source:"semantic-dom"};break}}const y=[/built[:\s]*(\d{4})/i,/year\s*built[:\s]*(\d{4})/i,/(\d{4})\s*(?:built|constructed)/i];for(const u of y){const m=t.match(u);if(m&&!e.yearBuilt){const p=parseInt(m[1],10);if(p>=1800&&p<=new Date().getFullYear()+1){e.yearBuilt={value:p,confidence:.6,source:"semantic-dom"};break}}}return e}function ye(e){const t={};if(e.toLowerCase(),!t.listPrice){const s=/(?:price|list|asking)[^$]*\$([\d,]+)/gi,n=[];let r;for(;(r=s.exec(e))!==null;){const a=parseInt(r[1].replace(/,/g,""),10);a>1e4&&a<1e7&&n.push({price:a,context:r[0].substring(0,50)})}if(n.length>0){const a=n.find(i=>i.context.toLowerCase().includes("list")||i.context.toLowerCase().includes("asking"))||n[0];t.listPrice={value:a.price,confidence:.4,source:"regex"}}}return t}function K(){const e={},t=pe();Object.assign(e,t);const s=ue();for(const[o,c]of Object.entries(s))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const n=fe();for(const[o,c]of Object.entries(n))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const r=he();for(const[o,c]of Object.entries(r))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);const a=ye(document.body.innerText);for(const[o,c]of Object.entries(a))(!e[o]||c.confidence>e[o].confidence)&&(e[o]=c);if(e.address){const o=ge(e.address.value);o.city&&!e.city&&(e.city={value:o.city,confidence:.7,source:"parsed"}),o.state&&!e.state&&(e.state={value:o.state,confidence:.7,source:"parsed"}),o.zip&&!e.zip&&(e.zip={value:o.zip,confidence:.7,source:"parsed"})}let i="regex_v1";return Object.keys(t).length>0?i="structured_v1":Object.keys(r).length>0&&(i="semantic_v1"),{fields:e,extractorVersion:i}}function ge(e){const t={},s=e.match(/([^,]+),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)/);if(s)t.city=s[1].trim(),t.state=s[2],t.zip=s[3];else{const n=e.match(/([A-Z]{2})\s+(\d{5}(?:-\d{4})?)/);n&&(t.state=n[1],t.zip=n[2])}return t}function J(){const e=window.location.href;return e.includes("zillow.com/homedetails/")||e.includes("zillow.com/homes/")&&e.includes("_zpid")}function ve(e){const t=document.createElement("button");return t.id="dealmetrics-floating-btn",t.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
      <polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
    <span>Analyze</span>
  `,t.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2147483646;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    color: white;
    border: none;
    border-radius: 50px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  `,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.05)",t.style.boxShadow="0 6px 20px rgba(37, 99, 235, 0.5), 0 4px 10px rgba(0, 0, 0, 0.15)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)",t.style.boxShadow="0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)"}),t.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),e()}),t}function Q(e,t){const s=e.querySelector("span");s&&(s.textContent=t?"Close":"Analyze"),t?(e.style.background="linear-gradient(135deg, #64748b 0%, #475569 100%)",e.style.boxShadow="0 4px 14px rgba(100, 116, 139, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)"):(e.style.background="linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)",e.style.boxShadow="0 4px 14px rgba(37, 99, 235, 0.4), 0 2px 6px rgba(0, 0, 0, 0.1)")}function xe(e){if(document.getElementById("dealmetrics-floating-btn"))return document.getElementById("dealmetrics-floating-btn");if(!J())return null;const t=ve(e);return document.body.appendChild(t),t}function I(e,t,s){if(e===0||s===0)return 0;const n=t/100/12,r=s*12;return n===0?e/r:e*n*Math.pow(1+n,r)/(Math.pow(1+n,r)-1)}function be(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),s=I(t,e.interestRate,e.termYears),n=e.taxesAnnual/12,r=e.insuranceAnnual/12,a=e.pmiEnabled&&e.pmiMonthly||0;return s+a+n+r+e.hoaMonthly+e.utilitiesMonthly}function L(e){const t=e.rentMonthly+e.otherIncomeMonthly,s=t*(e.vacancyRate/100),n=t-s,a=e.rentMonthly===0&&e.managementRate===0?e.purchasePrice/100:t,i=a*(e.maintenanceRate/100),o=a*(e.capexRate/100),c=t*(e.managementRate/100),d=i+o+c+e.taxesAnnual/12+e.insuranceAnnual/12+e.hoaMonthly+e.utilitiesMonthly,f=n-d,y=f*12;return{monthly:f,annual:y}}function O(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),s=I(t,e.interestRate,e.termYears),n=e.pmiEnabled&&e.pmiMonthly||0,r=s+n;return{monthly:r,annual:r*12}}function X(e){const t=L(e),s=O(e),n=t.monthly-s.monthly,r=n*12;return{monthly:n,annual:r}}function we(e){const t=L(e);return e.purchasePrice===0?0:t.annual/e.purchasePrice*100}function Pe(e){const t=X(e),s=B(e);return s===0?0:t.annual/s*100}function Re(e){const t=L(e),s=O(e);return s.annual===0?0:t.annual/s.annual}function Me(e){const t=O(e),s=e.taxesAnnual/12+e.insuranceAnnual/12+e.hoaMonthly+e.utilitiesMonthly,n=e.vacancyRate/100,r=e.maintenanceRate/100,a=e.capexRate/100,i=e.managementRate/100,o=1-n-r-a-i;if(o<=0)return t.monthly+s;const c=(t.monthly+s-e.otherIncomeMonthly)/o;return Math.max(0,c)}function B(e){const t=e.purchasePrice*(e.downPaymentPct/100),s=e.purchasePrice*(e.closingCostRate/100);return t+s+e.rehabCost}function ke(e){const t=be(e),s=L(e),n=X(e),r=we(e),a=Pe(e),i=Re(e),o=Me(e),c=B(e);return{totalMonthlyPayment:t,noiMonthly:s.monthly,noiAnnual:s.annual,cashFlowMonthly:n.monthly,cashFlowAnnual:n.annual,capRate:r,cashOnCash:a,dscr:i,breakEvenRentMonthly:o,allInCashRequired:c}}function D(e,t,s,n){if(n<=0)return e;if(n>=s)return 0;const r=t/100/12,a=s*12,i=I(e,t,s),o=n*12;if(r===0)return e-i*o;const c=e*(Math.pow(1+r,a)-Math.pow(1+r,o))/(Math.pow(1+r,a)-1);return Math.max(0,c)}function q(e,t,s,n){const r=D(e,t,s,n-1),a=D(e,t,s,n);return r-a}function Ae(e,t,s,n){const a=I(e,t,s)*12,i=q(e,t,s,n);return a-i}function Ce(e,t,s=0){const{underwritingInputs:n,appreciationRate:r,rentGrowthRate:a,expenseGrowthRate:i}=e,o=n.purchasePrice*(1-n.downPaymentPct/100),c=n.purchasePrice*Math.pow(1+r/100,t),d=D(o,n.interestRate,n.termYears,t),f=c-d,y=Math.pow(1+a/100,t-1),v=n.rentMonthly*12*y,u=n.otherIncomeMonthly*12*y,m=v+u,p=m*(n.vacancyRate/100),h=m-p,b=Math.pow(1+i/100,t-1),w=n.taxesAnnual*b,R=n.insuranceAnnual*b,k=n.hoaMonthly*12*b,A=n.utilitiesMonthly*12*b,F=m*(n.maintenanceRate/100),oe=m*(n.capexRate/100),ie=m*(n.managementRate/100),_=w+R+k+A+F+oe+ie,G=h-_,re=I(o,n.interestRate,n.termYears),ce=n.pmiEnabled&&n.pmiMonthly||0,V=(re+ce)*12,le=q(o,n.interestRate,n.termYears,t),de=Ae(o,n.interestRate,n.termYears,t),U=G-V,me=s+U;return{year:t,propertyValue:c,loanBalance:d,equity:f,rentAnnual:v,otherIncomeAnnual:u,grossIncomeAnnual:m,vacancyLossAnnual:p,operatingExpensesAnnual:_,noiAnnual:G,debtServiceAnnual:V,principalPaidAnnual:le,interestPaidAnnual:de,cashFlowAnnual:U,cumulativeCashFlow:me}}function Se(e){const t=[];let s=0;for(let n=1;n<=e.holdingPeriodYears;n++){const r=Ce(e,n,s);t.push(r),s=r.cumulativeCashFlow}return t}function Ie(e,t=100,s=1e-4){const n=c=>e.reduce((d,f,y)=>d+f/Math.pow(1+c,y),0),r=c=>e.reduce((d,f,y)=>y===0?d:d-y*f/Math.pow(1+c,y+1),0);let a=.1;for(let c=0;c<t;c++){const d=n(a),f=r(a);if(Math.abs(f)<1e-10)break;const y=a-d/f;if(y<-.99?a=-.99:y>10?a=10:a=y,Math.abs(d)<s)return a*100}let i=-.99,o=10;for(let c=0;c<t;c++){const d=(i+o)/2,f=n(d);if(Math.abs(f)<s||(o-i)/2<s)return d*100;n(i)*f<0?o=d:i=d}return a*100}function $e(e,t){const s=t[t.length-1],n=B(e.underwritingInputs),r=s.propertyValue,a=r*(e.sellingCostRate/100),i=s.loanBalance,o=r-a-i,c=s.cumulativeCashFlow,d=o+c-n,f=n>0?d/n*100:0,y=e.holdingPeriodYears,v=n+d,u=n>0&&y>0?(Math.pow(v/n,1/y)-1)*100:0;return{salePrice:r,sellingCosts:a,loanPayoff:i,netProceedsFromSale:o,cumulativeCashFlow:c,totalProfit:d,initialInvestment:n,totalROI:f,annualizedROI:u}}function Fe(e){const t=Se(e),s=$e(e,t),n=B(e.underwritingInputs),r=[-n];for(let c=0;c<t.length;c++){const d=t[c];c===t.length-1?r.push(d.cashFlowAnnual+s.netProceedsFromSale):r.push(d.cashFlowAnnual)}const a=Ie(r),i=s.cumulativeCashFlow+s.netProceedsFromSale,o=n>0?i/n:0;return{yearlyProjections:t,exitScenario:s,irr:a,equityMultiple:o}}function Ee(e){const t=e.purchasePrice*(1-e.downPaymentPct/100),s=I(t,e.interestRate,e.termYears),n=e.taxesAnnual/12,r=e.insuranceAnnual/12,a=e.hoaMonthly,i=e.pmiEnabled&&e.pmiMonthly||0,o=e.purchasePrice*(e.maintenanceRate/100/12)+e.purchasePrice*(e.capexRate/100/12),c=s+i+n+r+a+e.utilitiesMonthly+o,d=e.purchasePrice*(e.downPaymentPct/100),f=e.purchasePrice*(e.closingCostRate/100),y=d+f+e.rehabCost,v=c*12,u=q(t,e.interestRate,e.termYears,1),m=v-u;return{allInMonthlyCost:c,mortgagePI:s,monthlyTaxes:n,monthlyInsurance:r,monthlyHOA:a,monthlyMaintenanceReserve:o,cashRequiredAtClose:y,annualGrossCost:v,annualPrincipalPaydown:u,annualNetCostOfOwnership:m}}const Te={purchaseType:"primary_residence",downPaymentPct:20,interestRate:7,termYears:30,closingCostRate:3,maintenanceRate:.5,capexRate:.5,vacancyRate:0,managementRate:0,estimatedRent:0,holdingPeriodYears:5,appreciationRate:3,rentGrowthRate:3,expenseGrowthRate:3,sellingCostRate:6},E={maintenanceRate:8,capexRate:5,vacancyRate:5,managementRate:8};function $(e){return e==null?"":String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}let P=null,l={...Te},g={},C=!1,S=null;async function ze(){try{S=(await chrome.storage.sync.get(["authToken","userEmail"])).authToken||null,C=!!S}catch{C=!1,S=null}}function x(e){return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:0,maximumFractionDigits:0}).format(e)}function T(e,t=1){return`${e.toFixed(t)}%`}function ee(){const e=g.listPrice||0,t=l.purchaseType==="primary_residence";return{purchasePrice:e,closingCostRate:l.closingCostRate,rehabCost:0,downPaymentPct:l.downPaymentPct,interestRate:l.interestRate,termYears:l.termYears,pmiEnabled:l.downPaymentPct<20,pmiMonthly:l.downPaymentPct<20?e*.005/12:0,taxesAnnual:g.taxesAnnual||e*.012,insuranceAnnual:g.insuranceAnnual||e*.0035,hoaMonthly:g.hoaMonthly||0,utilitiesMonthly:0,rentMonthly:t?0:l.estimatedRent||e*.007,otherIncomeMonthly:0,vacancyRate:t?0:l.vacancyRate,maintenanceRate:l.maintenanceRate,capexRate:l.capexRate,managementRate:t?0:l.managementRate}}function Le(){return{underwritingInputs:ee(),holdingPeriodYears:l.holdingPeriodYears,appreciationRate:l.appreciationRate,rentGrowthRate:l.rentGrowthRate,expenseGrowthRate:l.expenseGrowthRate,sellingCostRate:l.sellingCostRate}}function te(){const e=ee(),t=ke(e),s=l.purchaseType==="primary_residence",n=s?Ee(e):null,r=Le(),a=l.holdingPeriodYears>0?Fe(r):null,i=$(g.address||"Property Address"),o=g.listPrice?x(g.listPrice):"$--",c=$(String(g.beds??"--")),d=$(String(g.baths??"--")),f=$(g.sqft?g.sqft.toLocaleString():"--"),y=e.purchasePrice*(1-e.downPaymentPct/100),v=y>0?y*(e.interestRate/100/12)*Math.pow(1+e.interestRate/100/12,e.termYears*12)/(Math.pow(1+e.interestRate/100/12,e.termYears*12)-1):0,u=e.taxesAnnual/12,m=e.insuranceAnnual/12,p=e.pmiEnabled?e.pmiMonthly:0,h=v+p+u+m+e.hoaMonthly;return`
    <div class="dm-sidebar-header">
      <div class="dm-sidebar-title">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
          <polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
        <span>DealMetrics</span>
      </div>
      <button class="dm-close-btn" id="dm-close-sidebar">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    
    <div class="dm-sidebar-content">
      <!-- Property Summary -->
      <div class="dm-section dm-property-summary">
        <div class="dm-property-address">${i}</div>
        <div class="dm-property-details">
          <span class="dm-price">${o}</span>
          <span class="dm-separator">|</span>
          <span>${c} bd</span>
          <span class="dm-separator">|</span>
          <span>${d} ba</span>
          <span class="dm-separator">|</span>
          <span>${f} sqft</span>
        </div>
        <button class="dm-refresh-btn" id="dm-refresh-data">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 4v6h-6M1 20v-6h6"/>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
          </svg>
          Refresh
        </button>
      </div>
      
      <!-- Assumptions -->
      <div class="dm-section dm-assumptions">
        <div class="dm-section-header">
          <span>Assumptions</span>
          <button class="dm-toggle-advanced" id="dm-toggle-advanced">Advanced</button>
        </div>
        
        <div class="dm-input-row">
          <label>Purchase Type</label>
          <select id="dm-purchase-type" class="dm-select">
            <option value="primary_residence" ${l.purchaseType==="primary_residence"?"selected":""}>Primary Residence</option>
            <option value="investment_property" ${l.purchaseType==="investment_property"?"selected":""}>Investment</option>
            <option value="house_hack" ${l.purchaseType==="house_hack"?"selected":""}>House Hack</option>
          </select>
        </div>
        
        <div class="dm-input-row">
          <label>Down Payment</label>
          <div class="dm-input-group">
            <input type="number" id="dm-down-payment" value="${l.downPaymentPct}" min="0" max="100" step="1" class="dm-input">
            <span class="dm-input-suffix">%</span>
          </div>
        </div>
        
        <div class="dm-input-row">
          <label>Interest Rate</label>
          <div class="dm-input-group">
            <input type="number" id="dm-interest-rate" value="${l.interestRate}" min="0" max="20" step="0.125" class="dm-input">
            <span class="dm-input-suffix">%</span>
          </div>
        </div>
        
        <div class="dm-input-row">
          <label>Loan Term</label>
          <select id="dm-loan-term" class="dm-select">
            <option value="30" ${l.termYears===30?"selected":""}>30 years</option>
            <option value="15" ${l.termYears===15?"selected":""}>15 years</option>
          </select>
        </div>
        
        <!-- Advanced inputs (hidden by default) -->
        <div class="dm-advanced-inputs" id="dm-advanced-inputs" style="display: none;">
          <div class="dm-input-row">
            <label>Closing Costs</label>
            <div class="dm-input-group">
              <input type="number" id="dm-closing-costs" value="${l.closingCostRate}" min="0" max="10" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          ${s?"":`
          <div class="dm-input-row">
            <label>Vacancy Rate</label>
            <div class="dm-input-group">
              <input type="number" id="dm-vacancy" value="${l.vacancyRate}" min="0" max="50" step="1" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          <div class="dm-input-row">
            <label>Management Fee</label>
            <div class="dm-input-group">
              <input type="number" id="dm-management" value="${l.managementRate}" min="0" max="20" step="1" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          `}
          
          <div class="dm-input-row">
            <label>Maintenance</label>
            <div class="dm-input-group">
              <input type="number" id="dm-maintenance" value="${l.maintenanceRate}" min="0" max="20" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          <div class="dm-input-row">
            <label>CapEx Reserve</label>
            <div class="dm-input-group">
              <input type="number" id="dm-capex" value="${l.capexRate}" min="0" max="20" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
          
          ${s?"":`
          <div class="dm-input-row">
            <label>Expected Rent</label>
            <div class="dm-input-group">
              <span class="dm-input-prefix">$</span>
              <input type="number" id="dm-rent" value="${l.estimatedRent}" min="0" step="50" class="dm-input dm-input-currency">
              <span class="dm-input-suffix">/mo</span>
            </div>
          </div>
          `}
        </div>
      </div>
      
      <!-- Monthly Payment Breakdown (FREE) -->
      <div class="dm-section dm-metrics">
        <div class="dm-section-header">
          <span>Monthly Payment</span>
        </div>
        
        <div class="dm-metric-row">
          <span class="dm-metric-label">Principal & Interest</span>
          <span class="dm-metric-value">${x(v)}</span>
        </div>
        ${p>0?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">PMI</span>
          <span class="dm-metric-value">${x(p)}</span>
        </div>
        `:""}
        <div class="dm-metric-row">
          <span class="dm-metric-label">
            Property Taxes
            <span class="dm-tax-source">${g.taxSource==="actual"&&g.taxYear?`(${g.taxYear})`:"(est.)"}</span>
          </span>
          <span class="dm-metric-value">${x(u)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">
            Insurance
            <span class="dm-tax-source">${g.insuranceSource==="actual"?"(Zillow)":"(est.)"}</span>
          </span>
          <span class="dm-metric-value">${x(m)}</span>
        </div>
        ${e.hoaMonthly>0?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">HOA</span>
          <span class="dm-metric-value">${x(e.hoaMonthly)}</span>
        </div>
        `:""}
        <div class="dm-metric-row dm-metric-total">
          <span class="dm-metric-label">Total Monthly</span>
          <span class="dm-metric-value">${x(h)}</span>
        </div>
      </div>
      
      <!-- Key Metrics (FREE) -->
      <div class="dm-section dm-metrics">
        <div class="dm-section-header">
          <span>Key Metrics</span>
          <span class="dm-badge dm-badge-free">FREE</span>
        </div>
        
        <div class="dm-metric-row dm-metric-highlight">
          <span class="dm-metric-label">Cash Required</span>
          <span class="dm-metric-value">${x(t.allInCashRequired)}</span>
        </div>
        
        ${s?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">True Monthly Cost</span>
          <span class="dm-metric-value dm-metric-subtext">
            ${x(n!=null&&n.annualNetCostOfOwnership?n.annualNetCostOfOwnership/12:0)}
            <small>(after equity)</small>
          </span>
        </div>
        `:`
        <div class="dm-metric-row ${t.cashFlowMonthly>=0?"dm-positive":"dm-negative"}">
          <span class="dm-metric-label">Monthly Cash Flow</span>
          <span class="dm-metric-value">${x(t.cashFlowMonthly)}</span>
        </div>
        
        <div class="dm-metric-row ${t.cashOnCash>=0?"dm-positive":"dm-negative"}">
          <span class="dm-metric-label">Cash-on-Cash Return</span>
          <span class="dm-metric-value">${T(t.cashOnCash)}</span>
        </div>
        `}
      </div>
      
      <!-- Holding Period Analysis (website-style: assumptions + metrics + exit scenario) -->
      <div class="dm-section dm-holding-period">
        <div class="dm-section-header">
          <span>${l.holdingPeriodYears}-Year ${s?"Ownership":"Holding Period"} Analysis</span>
        </div>
        
        <p class="dm-holding-desc">Configure assumptions for multi-year projections.</p>
        
        <div class="dm-holding-inputs" id="dm-holding-inputs">
          <div class="dm-input-row">
            <label>Hold (years)</label>
            <div class="dm-input-group">
              <input type="number" id="dm-holding-years" value="${l.holdingPeriodYears}" min="1" max="30" step="1" class="dm-input">
              <span class="dm-input-suffix">yrs</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Appreciation</label>
            <div class="dm-input-group">
              <input type="number" id="dm-appreciation" value="${l.appreciationRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Rent Growth</label>
            <div class="dm-input-group">
              <input type="number" id="dm-rent-growth" value="${l.rentGrowthRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Expense Growth</label>
            <div class="dm-input-group">
              <input type="number" id="dm-expense-growth" value="${l.expenseGrowthRate}" min="-5" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%/yr</span>
            </div>
          </div>
          <div class="dm-input-row">
            <label>Selling Cost</label>
            <div class="dm-input-group">
              <input type="number" id="dm-selling-cost" value="${l.sellingCostRate}" min="0" max="15" step="0.5" class="dm-input">
              <span class="dm-input-suffix">%</span>
            </div>
          </div>
        </div>
        
        ${a?`
        <div class="dm-holding-cards">
          <div class="dm-holding-card dm-card-irr">
            <div class="dm-holding-card-label">IRR</div>
            <div class="dm-holding-card-value ${a.irr>=0?"dm-positive":"dm-negative"}">${T(a.irr)}</div>
            <div class="dm-holding-card-hint">Annualized return</div>
          </div>
          <div class="dm-holding-card dm-card-em">
            <div class="dm-holding-card-label">Equity Multiple</div>
            <div class="dm-holding-card-value">${a.equityMultiple.toFixed(2)}x</div>
            <div class="dm-holding-card-hint">Total return / invested</div>
          </div>
          <div class="dm-holding-card dm-card-profit">
            <div class="dm-holding-card-label">Total Profit</div>
            <div class="dm-holding-card-value ${a.exitScenario.totalProfit>=0?"dm-positive":"dm-negative"}">${x(a.exitScenario.totalProfit)}</div>
            <div class="dm-holding-card-hint">Cash flow + sale - investment</div>
          </div>
          <div class="dm-holding-card dm-card-roi">
            <div class="dm-holding-card-label">Total ROI</div>
            <div class="dm-holding-card-value ${a.exitScenario.totalROI>=0?"dm-positive":"dm-negative"}">${T(a.exitScenario.totalROI)}</div>
            <div class="dm-holding-card-hint">Profit / initial investment</div>
          </div>
        </div>
        
        <div class="dm-exit-scenario">
          <div class="dm-exit-title">Exit Scenario (Year ${l.holdingPeriodYears})</div>
          <div class="dm-exit-rows">
            <div class="dm-exit-row">
              <span class="dm-exit-label">Sale Price</span>
              <span class="dm-exit-value">${x(a.exitScenario.salePrice)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">Selling Costs</span>
              <span class="dm-exit-value dm-negative">-${x(a.exitScenario.sellingCosts)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">Loan Payoff</span>
              <span class="dm-exit-value dm-negative">-${x(a.exitScenario.loanPayoff)}</span>
            </div>
            <div class="dm-exit-row dm-exit-row-highlight">
              <span class="dm-exit-label">Net Proceeds</span>
              <span class="dm-exit-value dm-positive">${x(a.exitScenario.netProceedsFromSale)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">Cumulative Cash Flow</span>
              <span class="dm-exit-value ${a.exitScenario.cumulativeCashFlow>=0?"dm-positive":"dm-negative"}">${x(a.exitScenario.cumulativeCashFlow)}</span>
            </div>
            <div class="dm-exit-row">
              <span class="dm-exit-label">Initial Investment</span>
              <span class="dm-exit-value">${x(a.exitScenario.initialInvestment)}</span>
            </div>
          </div>
        </div>
        
        ${a.yearlyProjections.length>0?`
        <div class="dm-yearly-summary">
          <div class="dm-yearly-title">Projection Snapshot</div>
          <div class="dm-yearly-rows">
            <div class="dm-yearly-row">
              <span class="dm-yearly-label">Year 1 Cash Flow</span>
              <span class="dm-yearly-value ${a.yearlyProjections[0].cashFlowAnnual>=0?"dm-positive":"dm-negative"}">${x(a.yearlyProjections[0].cashFlowAnnual)}</span>
            </div>
            ${l.holdingPeriodYears>=3&&a.yearlyProjections.length>=Math.ceil(l.holdingPeriodYears/2)?`
            <div class="dm-yearly-row">
              <span class="dm-yearly-label">Year ${Math.ceil(l.holdingPeriodYears/2)} Cash Flow</span>
              <span class="dm-yearly-value ${a.yearlyProjections[Math.ceil(l.holdingPeriodYears/2)-1].cashFlowAnnual>=0?"dm-positive":"dm-negative"}">${x(a.yearlyProjections[Math.ceil(l.holdingPeriodYears/2)-1].cashFlowAnnual)}</span>
            </div>
            `:""}
            <div class="dm-yearly-row">
              <span class="dm-yearly-label">Year ${l.holdingPeriodYears} Cash Flow</span>
              <span class="dm-yearly-value ${a.yearlyProjections[a.yearlyProjections.length-1].cashFlowAnnual>=0?"dm-positive":"dm-negative"}">${x(a.yearlyProjections[a.yearlyProjections.length-1].cashFlowAnnual)}</span>
            </div>
            <div class="dm-yearly-row">
              <span class="dm-yearly-label">End Equity</span>
              <span class="dm-yearly-value">${x(a.yearlyProjections[a.yearlyProjections.length-1].equity)}</span>
            </div>
          </div>
        </div>
        `:""}
        `:""}
      </div>
      
      <!-- Premium Metrics (LOCKED) -->
      <div class="dm-section dm-metrics dm-premium ${C?"":"dm-locked"}">
        <div class="dm-section-header">
          <span>Advanced Analysis</span>
          ${C?"":'<span class="dm-badge dm-badge-premium">PRO</span>'}
        </div>
        
        ${C?`
        <div class="dm-metric-row">
          <span class="dm-metric-label">Cap Rate</span>
          <span class="dm-metric-value">${T(t.capRate)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">NOI (Annual)</span>
          <span class="dm-metric-value">${x(t.noiAnnual)}</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">DSCR</span>
          <span class="dm-metric-value">${t.dscr.toFixed(2)}x</span>
        </div>
        <div class="dm-metric-row">
          <span class="dm-metric-label">Break-Even Rent</span>
          <span class="dm-metric-value">${x(t.breakEvenRentMonthly)}</span>
        </div>
        `:`
        <div class="dm-lock-overlay">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
          <span>Cap Rate, NOI, DSCR, IRR...</span>
          <button class="dm-btn dm-btn-primary dm-btn-small" id="dm-sign-in">Sign in to unlock</button>
        </div>
        `}
      </div>
    </div>
    
    <!-- Footer Actions -->
    <div class="dm-sidebar-footer">
      ${C?`
      <button class="dm-btn dm-btn-primary dm-btn-full" id="dm-save-deal">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
          <polyline points="17 21 17 13 7 13 7 21"/>
          <polyline points="7 3 7 8 15 8"/>
        </svg>
        Save to Dashboard
      </button>
      `:`
      <button class="dm-btn dm-btn-primary dm-btn-full" id="dm-sign-in-footer">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
          <polyline points="10 17 15 12 10 7"/>
          <line x1="15" y1="12" x2="3" y2="12"/>
        </svg>
        Sign in to Save
      </button>
      `}
      <div class="dm-footer-links">
        <a href="https://getdealmetrics.com" target="_blank">Open DealMetrics</a>
      </div>
    </div>
  `}function Be(){return`
    #dealmetrics-sidebar {
      position: fixed;
      top: 0;
      right: 0;
      width: 360px;
      height: 100vh;
      background: #ffffff;
      box-shadow: -4px 0 20px rgba(0, 0, 0, 0.15);
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      color: #1f2937;
      font-size: 14px;
      line-height: 1.5;
    }
    
    .dm-sidebar-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 20px;
      background: linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 100%);
      color: white;
    }
    
    .dm-sidebar-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      font-size: 16px;
    }
    
    .dm-close-btn {
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 8px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s;
    }
    
    .dm-close-btn:hover {
      background: rgba(255, 255, 255, 0.2);
    }
    
    .dm-sidebar-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    
    .dm-section {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 12px;
    }
    
    .dm-section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      font-weight: 600;
      color: #374151;
    }
    
    .dm-property-summary {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-color: #bae6fd;
    }
    
    .dm-property-address {
      font-weight: 600;
      font-size: 15px;
      color: #0f172a;
      margin-bottom: 4px;
    }
    
    .dm-property-details {
      color: #64748b;
      font-size: 13px;
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    
    .dm-price {
      font-weight: 600;
      color: #0369a1;
    }
    
    .dm-separator {
      color: #cbd5e1;
    }
    
    .dm-refresh-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      margin-top: 12px;
      padding: 6px 12px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      font-size: 12px;
      color: #64748b;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .dm-refresh-btn:hover {
      background: #f1f5f9;
      color: #334155;
    }
    
    .dm-input-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .dm-input-row label {
      font-size: 13px;
      color: #4b5563;
    }
    
    .dm-input-group {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .dm-input, .dm-select {
      width: 80px;
      padding: 6px 8px;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 13px;
      color: #1f2937;
      background: white;
      text-align: right;
    }
    
    .dm-input:focus, .dm-select:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }
    
    .dm-select {
      width: auto;
      text-align: left;
      cursor: pointer;
    }
    
    .dm-input-suffix, .dm-input-prefix {
      font-size: 12px;
      color: #9ca3af;
    }
    
    .dm-input-currency {
      width: 90px;
    }
    
    .dm-toggle-advanced {
      font-size: 12px;
      color: #6b7280;
      background: none;
      border: none;
      cursor: pointer;
      text-decoration: underline;
    }
    
    .dm-toggle-advanced:hover {
      color: #3b82f6;
    }
    
    .dm-holding-desc {
      font-size: 12px;
      color: #6b7280;
      margin: 0 0 12px 0;
    }
    
    .dm-holding-inputs {
      margin-bottom: 14px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px 12px;
    }
    
    .dm-holding-inputs .dm-input-row {
      margin-bottom: 0;
    }
    
    .dm-holding-cards {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    
    .dm-holding-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
    }
    
    .dm-holding-card-label {
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.02em;
      margin-bottom: 2px;
    }
    
    .dm-holding-card-value {
      font-size: 16px;
      font-weight: 700;
      color: #1e293b;
    }
    
    .dm-holding-card-hint {
      font-size: 10px;
      color: #94a3b8;
      margin-top: 2px;
    }
    
    .dm-exit-scenario {
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 12px;
    }
    
    .dm-exit-title {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 8px;
    }
    
    .dm-exit-rows {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .dm-exit-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
    }
    
    .dm-exit-row-highlight {
      border-top: 1px solid #cbd5e1;
      margin-top: 4px;
      padding-top: 6px;
      font-weight: 600;
    }
    
    .dm-exit-label {
      color: #64748b;
    }
    
    .dm-exit-value {
      font-weight: 600;
      color: #1e293b;
    }
    
    .dm-yearly-summary {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
    }
    
    .dm-yearly-title {
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 6px;
    }
    
    .dm-yearly-rows {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    
    .dm-yearly-row {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
    }
    
    .dm-yearly-label {
      color: #64748b;
    }
    
    .dm-yearly-value {
      font-weight: 500;
      color: #1e293b;
    }
    
    .dm-advanced-inputs {
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px dashed #e5e7eb;
    }
    
    .dm-metric-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid #f1f5f9;
    }
    
    .dm-metric-row:last-child {
      border-bottom: none;
    }
    
    .dm-metric-label {
      font-size: 13px;
      color: #6b7280;
    }
    
    .dm-tax-source {
      font-size: 10px;
      color: #9ca3af;
      font-weight: 400;
      margin-left: 4px;
    }
    
    .dm-metric-value {
      font-weight: 600;
      color: #1f2937;
    }
    
    .dm-metric-subtext {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    
    .dm-metric-subtext small {
      font-size: 10px;
      font-weight: 400;
      color: #9ca3af;
    }
    
    .dm-metric-total {
      margin-top: 8px;
      padding-top: 12px;
      border-top: 2px solid #e2e8f0;
    }
    
    .dm-metric-total .dm-metric-value {
      font-size: 16px;
      color: #0369a1;
    }
    
    .dm-metric-highlight {
      background: #f0f9ff;
      margin: -8px -16px;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 8px;
    }
    
    .dm-positive .dm-metric-value {
      color: #059669;
    }
    
    .dm-negative .dm-metric-value {
      color: #dc2626;
    }
    
    .dm-badge {
      font-size: 10px;
      font-weight: 600;
      padding: 2px 8px;
      border-radius: 10px;
      text-transform: uppercase;
    }
    
    .dm-badge-free {
      background: #dcfce7;
      color: #166534;
    }
    
    .dm-badge-premium {
      background: #fef3c7;
      color: #92400e;
    }
    
    .dm-premium.dm-locked {
      position: relative;
    }
    
    .dm-lock-overlay {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      text-align: center;
      color: #6b7280;
      gap: 8px;
    }
    
    .dm-lock-overlay svg {
      color: #9ca3af;
    }
    
    .dm-lock-overlay span {
      font-size: 12px;
    }
    
    .dm-sidebar-footer {
      padding: 16px;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
    }
    
    .dm-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 10px 16px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      border: none;
    }
    
    .dm-btn-primary {
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
    }
    
    .dm-btn-primary:hover {
      background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
    }
    
    .dm-btn-full {
      width: 100%;
    }
    
    .dm-btn-small {
      padding: 6px 12px;
      font-size: 12px;
    }
    
    .dm-footer-links {
      display: flex;
      justify-content: center;
      margin-top: 12px;
    }
    
    .dm-footer-links a {
      font-size: 12px;
      color: #6b7280;
      text-decoration: none;
    }
    
    .dm-footer-links a:hover {
      color: #3b82f6;
      text-decoration: underline;
    }
    
    .dm-saving {
      opacity: 0.7;
      pointer-events: none;
    }
    
    .dm-success-msg {
      background: #dcfce7;
      color: #166534;
      padding: 12px;
      border-radius: 8px;
      text-align: center;
      font-size: 13px;
      margin-bottom: 12px;
    }
    
    .dm-error-msg {
      background: #fee2e2;
      color: #dc2626;
      padding: 12px;
      border-radius: 8px;
      text-align: center;
      font-size: 13px;
      margin-bottom: 12px;
    }
  `}function N(){P&&(P.innerHTML=te(),ne())}function De(e,t){switch(e){case"dm-purchase-type":const s=t;l.purchaseType=s,s==="primary_residence"?(l.maintenanceRate=.5,l.capexRate=.5,l.vacancyRate=0,l.managementRate=0):(l.maintenanceRate=E.maintenanceRate,l.capexRate=E.capexRate,l.vacancyRate=E.vacancyRate,l.managementRate=E.managementRate);break;case"dm-down-payment":l.downPaymentPct=Number(t);break;case"dm-interest-rate":l.interestRate=Number(t);break;case"dm-loan-term":l.termYears=Number(t);break;case"dm-closing-costs":l.closingCostRate=Number(t);break;case"dm-vacancy":l.vacancyRate=Number(t);break;case"dm-management":l.managementRate=Number(t);break;case"dm-maintenance":l.maintenanceRate=Number(t);break;case"dm-capex":l.capexRate=Number(t);break;case"dm-rent":l.estimatedRent=Number(t);break;case"dm-holding-years":l.holdingPeriodYears=Math.max(1,Math.min(30,Number(t)||5));break;case"dm-appreciation":l.appreciationRate=Number(t);break;case"dm-rent-growth":l.rentGrowthRate=Number(t);break;case"dm-expense-growth":l.expenseGrowthRate=Number(t);break;case"dm-selling-cost":l.sellingCostRate=Math.max(0,Number(t));break}N()}function je(e){try{if(!e||typeof e!="object")return null;const t=e,s=t==null?void 0:t.dealId;if(typeof s=="string")return s;const n=t==null?void 0:t.data;if(n&&typeof n=="object"){const r=n,a=r==null?void 0:r.dealId;if(typeof a=="string")return a;const i=r==null?void 0:r.deal;if(i!=null&&typeof i=="object"){const o=i==null?void 0:i.id;if(typeof o=="string")return o}}}catch{return null}return null}async function Ye(){var t;if(!S){alert("Please sign in to save deals");return}const e=document.getElementById("dm-save-deal");e&&(e.classList.add("dm-saving"),e.innerHTML="Saving...");try{const s={zillowUrl:g.zillowUrl||window.location.href,extractedData:{address:g.address,city:g.city,state:g.state,zip:g.zip,propertyType:g.propertyType,beds:g.beds,baths:g.baths,sqft:g.sqft,yearBuilt:g.yearBuilt,listPrice:g.listPrice,hoaMonthly:g.hoaMonthly,taxesAnnual:g.taxesAnnual},purchaseType:l.purchaseType,downPaymentPct:l.downPaymentPct,importedFields:Object.keys(g).filter(a=>g[a]!==void 0),missingFields:[],fieldConfidences:{},extractorVersion:"sidebar_v1"};console.log("[DealMetrics] Saving deal...",{payload:s,hasToken:!!S});const n=await chrome.runtime.sendMessage({action:"saveDeal",payload:s,authToken:S});if(console.log("[DealMetrics] Save response:",n),!n)throw new Error("No response from background script - extension may need reload");if(!n.success)throw new Error(n.error||"Failed to save deal");let r=null;try{r=je(n)}catch{r=null}r||console.warn("[DealMetrics] Save succeeded but dealId missing from response shape:",n);try{const a=document.querySelector(".dm-sidebar-content");if(a){const i=document.createElement("div");i.className="dm-success-msg";const o=r?`Deal saved! <a href="https://getdealmetrics.com/deals/${$(r)}" target="_blank">View in Dashboard</a>`:'Deal saved! <a href="https://getdealmetrics.com/dashboard" target="_blank">View in Dashboard</a>';i.innerHTML=o,a.insertBefore(i,a.firstChild)}}catch(a){console.error("[DealMetrics] Error showing success message:",a)}e&&(e.innerHTML="Saved!",setTimeout(()=>{e&&(e.classList.remove("dm-saving"),e.innerHTML=`
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
              <polyline points="17 21 17 13 7 13 7 21"/>
              <polyline points="7 3 7 8 15 8"/>
            </svg>
            Save to Dashboard
          `)},2e3))}catch(s){console.error("Save error:",s);const n=s.message||"Failed to save deal",r=n.toLowerCase().includes("token")||n.toLowerCase().includes("unauthorized")||n.toLowerCase().includes("401");r&&(await chrome.storage.sync.remove(["authToken","refreshToken","userEmail"]),C=!1,S=null);const a=document.querySelector(".dm-sidebar-content");if(a){const i=document.createElement("div");i.className="dm-error-msg",r?i.innerHTML=`
          Session expired. <button id="dm-reauth-btn" style="color: #2563eb; text-decoration: underline; background: none; border: none; cursor: pointer;">Sign in again</button>
        `:i.textContent=n,a.insertBefore(i,a.firstChild),r&&((t=document.getElementById("dm-reauth-btn"))==null||t.addEventListener("click",()=>{j()}))}e&&(e.classList.remove("dm-saving"),e.innerHTML=`
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
          <polyline points="17 21 17 13 7 13 7 21"/>
          <polyline points="7 3 7 8 15 8"/>
        </svg>
        Save to Dashboard
      `),r&&setTimeout(()=>N(),500)}}function j(){const t=`https://getdealmetrics.com/auth/extension?_=${Date.now()}`;window.open(t,"_blank")}function ne(){var t,s,n,r,a,i;(t=document.getElementById("dm-close-sidebar"))==null||t.addEventListener("click",()=>{H()}),(s=document.getElementById("dm-refresh-data"))==null||s.addEventListener("click",()=>{ae()}),(n=document.getElementById("dm-toggle-advanced"))==null||n.addEventListener("click",()=>{const o=document.getElementById("dm-advanced-inputs");o&&(o.style.display=o.style.display==="none"?"block":"none")}),["dm-purchase-type","dm-down-payment","dm-interest-rate","dm-loan-term","dm-closing-costs","dm-vacancy","dm-management","dm-maintenance","dm-capex","dm-rent","dm-holding-years","dm-appreciation","dm-rent-growth","dm-expense-growth","dm-selling-cost"].forEach(o=>{const c=document.getElementById(o);c&&c.addEventListener("change",()=>{De(o,c.value)})}),(r=document.getElementById("dm-save-deal"))==null||r.addEventListener("click",Ye),(a=document.getElementById("dm-sign-in"))==null||a.addEventListener("click",j),(i=document.getElementById("dm-sign-in-footer"))==null||i.addEventListener("click",j)}function ae(){var o,c,d,f,y,v,u,m,p,h,b,w,R,k,A,F;const t=K().fields,s=(o=t.taxesAnnual)==null?void 0:o.source,n=(s==null?void 0:s.startsWith("tax-history"))||s==="payment-breakdown",r=(c=t.taxYear)==null?void 0:c.value,i=((d=t.insuranceAnnual)==null?void 0:d.source)==="payment-breakdown";g={address:(f=t.address)==null?void 0:f.value,city:(y=t.city)==null?void 0:y.value,state:(v=t.state)==null?void 0:v.value,zip:(u=t.zip)==null?void 0:u.value,listPrice:(m=t.listPrice)==null?void 0:m.value,beds:(p=t.beds)==null?void 0:p.value,baths:(h=t.baths)==null?void 0:h.value,sqft:(b=t.sqft)==null?void 0:b.value,propertyType:(w=t.propertyType)==null?void 0:w.value,yearBuilt:(R=t.yearBuilt)==null?void 0:R.value,hoaMonthly:(k=t.hoaMonthly)==null?void 0:k.value,taxesAnnual:(A=t.taxesAnnual)==null?void 0:A.value,taxYear:r,taxSource:n?"actual":"estimated",insuranceAnnual:(F=t.insuranceAnnual)==null?void 0:F.value,insuranceSource:i?"actual":"estimated",zillowUrl:window.location.href},N()}function H(){P&&(P.remove(),P=null)}function z(){return P!==null}async function Oe(){if(P)return;await ze(),ae();const e="dealmetrics-sidebar-styles";if(!document.getElementById(e)){const t=document.createElement("style");t.id=e,t.textContent=Be(),document.head.appendChild(t)}P=document.createElement("div"),P.id="dealmetrics-sidebar",P.innerHTML=te(),document.body.appendChild(P),ne()}function se(){z()?H():Oe()}let M=null;function Y(){J()&&(M=xe(()=>{se(),M&&Q(M,z())}))}let Z=window.location.href;function W(){new MutationObserver(()=>{window.location.href!==Z&&(Z=window.location.href,H(),M&&(M.remove(),M=null),setTimeout(Y,1e3))}).observe(document.body,{childList:!0,subtree:!0})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{Y(),W()}):(Y(),W());chrome.runtime.onMessage.addListener((e,t,s)=>{if(e.action==="extract"){try{if(!window.location.hostname.includes("zillow.com"))return s({success:!1,error:"Not on a Zillow page"}),!0;const n=K(),r={},a=[],i={};for(const[d,f]of Object.entries(n.fields))f.value!==void 0&&f.value!==null&&(r[d]=f.value,a.push(d),i[d]=f.confidence);const o=[],c=["address","listPrice","beds","baths","sqft"];for(const d of c)a.includes(d)||o.push(d);s({success:!0,payload:{zillowUrl:window.location.href,extractedData:r,importedFields:a,missingFields:o,fieldConfidences:i,extractorVersion:n.extractorVersion}})}catch(n){s({success:!1,error:n.message||"Extraction failed"})}return!0}if(e.action==="toggleSidebar")return se(),M&&Q(M,z()),s({success:!0,isOpen:z()}),!0});
